#ifndef CARD
#define CARD

class Card {
  
private:
	int rank;
	int suit;  

public:
	
	Card();
	~Card();

	int get_rank();
	int get_suit();

	void set_rank(int);
	void set_suit(int);

	void print_card();

};

#endif