#include "./deck.h"

#include <iostream>

using std::cout;
using std::endl;
using std::rand;

/**********************************************************
 ** Function: Deck constructor
 ** Description: constructs a standard 52 card deck
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: created deck object
 **********************************************************/

Deck::Deck() {
	cards = new Card[52];
	for(int i = 0; i < 52; i++) {
		int r = i % 13 + 1;
		int s = i / 13;
		cards[i].set_rank(r);
		cards[i].set_suit(s);
	}
	n_cards = 52;
}

/**********************************************************
 ** Function: deck destructor
 ** Description: destroys a deck
 ** Parameters: none
 ** Pre-Conditions: deck exists and has cards to delete
 ** Post-Conditions: deck is destoyed
 **********************************************************/

Deck::~Deck() {
	delete [] cards;
}

/**********************************************************
 ** Function: get_card
 ** Description: returns a card of a given index
 ** Parameters: index for card
 ** Pre-Conditions: array contains element i
 ** Post-Conditions: returns card at given index
 **********************************************************/

Card Deck::get_card(int i) {
	return cards[i];
}

/**********************************************************
 ** Function: set_card
 ** Description: sets a card at a given index
 ** Parameters: card and index
 ** Pre-Conditions: card array contains element i
 ** Post-Conditions: card values are changed
 **********************************************************/

void Deck::set_card(Card card, int i) {
	cards[i] = card;
}

/**********************************************************
 ** Function: get_n_cards
 ** Description: returns the number of cards in a deck
 ** Parameters: none
 ** Pre-Conditions: expecting int returned
 ** Post-Conditions: returns n_cards
 **********************************************************/

int Deck::get_n_cards() {
	return n_cards;
}

/**********************************************************
 ** Function: shuffle
 ** Description: swaps cards to shuffle the deck
 ** Parameters: none
 ** Pre-Conditions: 52 cards in the deck (can handle more, but 
 					they won't be swapped)
 ** Post-Conditions: shuffled deck
 **********************************************************/

void Deck::shuffle() {
	for (int i = 0; i < 52; i++) {
		int swap_1 = rand() % 52;
		int swap_2 = rand() % 52;
		Card temp = cards[swap_1];
		cards[swap_1] = cards[swap_2];
		cards[swap_2] = temp;
	}
}

/**********************************************************
 ** Function: print_deck
 ** Description: outputs the deck
 ** Parameters: none
 ** Pre-Conditions: n_cards is number of elements
 ** Post-Conditions: prints each card on its own line
 **********************************************************/

void Deck::print_deck() {
	for (int i = 0; i < n_cards; i++) {
		cards[i].print_card();
		cout << endl;
	}
}

/**********************************************************
 ** Function: remove_card
 ** Description: removes the top card from the deck and 
 				 decrements n_cards
 ** Parameters: none
 ** Pre-Conditions: n_cards is correct
 ** Post-Conditions: new card array of 1 fewer elements and
 					 n_cards decremented
 **********************************************************/

Card Deck::remove_card() {
	if (n_cards > 0) {
		Card card = cards[n_cards - 1];
		Card* temp = new Card[n_cards - 1];
		if(n_cards > 1) {
			for (int i = 0; i < n_cards - 1; i++) {
				temp[i] = cards[i];
			}
		}
		delete [] cards;
		cards = temp;
		n_cards--;
		return card;
	}
	Card card;
	return card;
}


