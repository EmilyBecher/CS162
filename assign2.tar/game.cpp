#include "./game.h"

#include <iostream>

using std::cout;
using std::endl;

/**********************************************************
 ** Function: Game constructor
 ** Description: constructs game
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: game object created
 **********************************************************/

Game::Game() {
	cards;
	player;
	pile;
}

/**********************************************************
 ** Function: Game destructor
 ** Description: destroy game
 ** Parameters: none
 ** Pre-Conditions: hand and deck dynamic memory to delete
 ** Post-Conditions: all objects within game are destroyed
 **********************************************************/

Game::~Game() {
	
}

/**********************************************************
 ** Function: get_deck
 ** Description: returns deck
 ** Parameters: none
 ** Pre-Conditions: expecting deck
 ** Post-Conditions: returns deck
 **********************************************************/

Deck Game::get_deck() {
	return cards;
}

/**********************************************************
 ** Function: get_player
 ** Description: returns player of given index
 ** Parameters: player index
 ** Pre-Conditions: i is 0 or 1
 ** Post-Conditions: returns player at given index
 **********************************************************/

Player Game::get_player(int i) {
	return player[i];
}

/**********************************************************
 ** Function: set_player
 ** Description: set player
 ** Parameters: player and player's index
 ** Pre-Conditions: i is 0 or 1
 ** Post-Conditions: mutates player
 **********************************************************/

void Game::set_player(Player player, int i) {
	this -> player[i] = player;
}

/**********************************************************
 ** Function: get_pile
 ** Description: returns pile
 ** Parameters: none
 ** Pre-Conditions: expecting card
 ** Post-Conditions: returns top card of pile 
 **********************************************************/

Card Game::get_pile() {
	return pile;
}

/**********************************************************
 ** Function: set_pile
 ** Description: sets pile to given card
 ** Parameters: card
 ** Pre-Conditions: card exists
 ** Post-Conditions: pile is changed
 **********************************************************/

void Game::set_pile(Card card) {
	pile = card;
}

/**********************************************************
 ** Function: set_up
 ** Description: shuffles the deck, deal to players, and
 				  sets pile
 ** Parameters: none
 ** Pre-Conditions: 52 cards in the deck
 ** Post-Conditions: deck, players, and pile are ready for game
 **********************************************************/

void Game::set_up() {
	cards.shuffle();
	player[0].set_name("Your");
	player[1].set_name("Computer's");
	deal();
	pile = cards.remove_card();
}

/**********************************************************
 ** Function: play
 ** Description: handles gameplay and returns result
 ** Parameters: none
 ** Pre-Conditions: game has been set-up (players have hands
 					and pile has been initialized)
 ** Post-Conditions: returns game state
 **********************************************************/

int Game::play() {
	int result = 0;
	int turn = 0;
	//print info
	player[0].print_hand();
	cout << "Pile: ";
	pile.print_card();
	cout << endl;
	//user's turn
	turn = play_turn(0);
	if (turn == 1) { /*User wins*/
		return 1;
	}
	result += turn;
	//computer's turn
	cout << "Computer's turn" << endl;
	turn = play_turn(1);
	if (turn == 2) { /*Computer wins*/
		return 2;
	}
	result += turn;
	if (cards.get_n_cards() == 0) {
		if (result == -2) { /*tie*/
			return 3;
		}
	}
	return 0; /*game isn't over*/
}

/**********************************************************
 ** Function: deal
 ** Description: deals cards to both players
 ** Parameters: none
 ** Pre-Conditions: there are at least 14 cards in deck
 ** Post-Conditions: players have 7 new cards and deck
 					 no longer has thos cards
 **********************************************************/

void Game::deal() {
	for(int i = 0; i < 7; i++) { /*deal 7 cards*/
		Card c1;
		Card c2;
		c1 = cards.remove_card();
		c2 = cards.remove_card();
		player[0].add_card(c1);
		player[1].add_card(c2);
	}
}

/**********************************************************
 ** Function: play_turn
 ** Description: handles player's turn and returns result 
 ** Parameters: player index
 ** Pre-Conditions: index is 0 or 1
 ** Post-Conditions: returns if player played, drew, or won
 **********************************************************/

int Game::play_turn(int index) {
	int turn = player[index].turn(pile);
	if (turn == 1) { /*Draw a card*/
		Card temp;
		temp = cards.remove_card(); /*could return default card*/
		if (temp.get_suit() >= 0) { /*only add valid card*/
			player[index].add_card(temp);
		}
		return -1; /*can't play*/
	}
	if (player[index].get_hand().get_n_cards() == 0) {
		return index + 1; /*win condition*/
	}
	return 0;
}

