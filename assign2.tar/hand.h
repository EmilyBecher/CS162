#ifndef HAND
#define HAND

#include "./card.h"

class Hand {

private:
	Card* cards;
	int n_cards;

public:
	Hand();
	~Hand();
	Hand(const Hand &);
	Hand & operator=(const Hand &);

	Card get_card(int);
	int get_n_cards();

	void add_card(Card);
	void print_hand();
	Card remove_card(int);

	bool can_play(Card);
	Card card_to_play();
	void get_int(int&);
	
};




#endif