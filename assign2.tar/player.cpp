#include "./player.h"

#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::cin;
using std::string;

/**********************************************************
 ** Function: Player constructor
 ** Description: creates player object
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: creates player object
 **********************************************************/

Player::Player() {
	hand;
	name = "";
} 

/**********************************************************
 ** Function: Player destructor
 ** Description: destroys player
 ** Parameters: none
 ** Pre-Conditions: player hands have dynamic memory
 ** Post-Conditions: player destroyed
 **********************************************************/

Player::~Player() {
	
}

/**********************************************************
 ** Function: get_hand
 ** Description: returns hand
 ** Parameters: none
 ** Pre-Conditions: expects hand object
 ** Post-Conditions: returns hand
 **********************************************************/

Hand Player::get_hand() {
	return hand;
}

/**********************************************************
 ** Function: get_name
 ** Description: returns name
 ** Parameters: none
 ** Pre-Conditions: expects string
 ** Post-Conditions: returns player name
 **********************************************************/

string Player::get_name() {
	return name;
}

/**********************************************************
 ** Function: set_name
 ** Description: sets name
 ** Parameters: string
 ** Pre-Conditions: none
 ** Post-Conditions: mutates name
 **********************************************************/

void Player::set_name(string name) {
	this -> name = name;
}

/**********************************************************
 ** Function: print_hand
 ** Description: Outputs hand contents with name
 ** Parameters: none
 ** Pre-Conditions: expects name to be in possesive form
 ** Post-Conditions: prints hand and player name
 **********************************************************/

void Player::print_hand() {
	cout << name << " Hand:" << endl;
	hand.print_hand();
}

/**********************************************************
 ** Function: add_card
 ** Description: adds card to hand
 ** Parameters: card to add
 ** Pre-Conditions: n_cards is correct (for add_card())
 ** Post-Conditions: adds card to hand
 **********************************************************/

void Player::add_card(Card card) {
	hand.add_card(card);
}

/**********************************************************
 ** Function: turn
 ** Description: plays card or draws card
 ** Parameters: pile address
 ** Pre-Conditions: called functions need n_cards to be right
 ** Post-Conditions: plays players turn
 **********************************************************/

int Player::turn(Card& pile) {
	bool play = 0;
	Card card;
	bool check = 0;
	//check that hand contains playable card
	play = hand.can_play(pile);
	if (play == 0) { /*If no playable card*/
		cout << name << " hand doesn't have a card to play." << endl;
		cout << "A card has been drawn." << endl << endl;
		return 1;
	}
	//if user, get card
	if (name == "Your") {
		while (!check) {
			card = hand.card_to_play();
			check = can_play(card, pile);
		}
	}
	else { /*Computer, cycle through cards*/
		for (int i = 0; i < hand.get_n_cards(); i++) {
			card = hand.get_card(i);
			check = can_play(card, pile);
			if (check == 1) { /*Found playable card*/
				break;
			}
		}
	}
	//play card
	play_card(card, pile);
}

/**********************************************************
 ** Function: can_play
 ** Description: checks that card can be played
 ** Parameters: card and pile address
 ** Pre-Conditions: pile is valid card 
 ** Post-Conditions: returns if card can be played
 **********************************************************/

bool Player::can_play(Card card, Card& pile) {
	int pile_suit = pile.get_suit();
	int pile_rank = pile.get_rank();
	int card_rank = card.get_rank();

	if (card_rank == pile_rank) {
		return 1;
	}
	else if (card_rank == 8) {
		get_suit(pile);
		return 1;
	}
	int card_suit = card.get_suit();
	if (card_suit == pile_suit) {
		return 1;
	}
	return 0;
}

/**********************************************************
 ** Function: play_card
 ** Description: remove played card from hand and put it
 				 on the pile
 ** Parameters: card and pile address
 ** Pre-Conditions: remove_card requires n_cards to be correct
 ** Post-Conditions: pile is updated and card is removed from hand
 **********************************************************/

void Player::play_card(Card card, Card& pile) {
	if (card.get_rank() != 8) { /*set pile to card unless 8*/
		pile = card;
	}
	cout << "Card played: ";
	card.print_card();
	cout << endl << endl;
	/* Find card index and remove card */
	for (int i = 0; i < hand.get_n_cards(); i++) { 
		if (hand.get_card(i).get_rank() == card.get_rank()) {
			if (hand.get_card(i).get_suit() == card.get_suit()) {
				hand.remove_card(i);
				break;
			}
		}
	}
}

/**********************************************************
 ** Function: get_suit
 ** Description: when 8 is played get suit and set pile
 ** Parameters: pile address
 ** Pre-Conditions: 8 was played
 ** Post-Conditions: updates pile
 **********************************************************/

void Player::get_suit(Card& pile) {
	int suit = 0;
	if (name == "Your") {
		get_int(suit);
	}
	else {
		suit = hand.get_card(0).get_suit();
	}
	pile.set_suit(suit);
	pile.set_rank(0); /*zero to force the suit to be played*/
}

/**********************************************************
 ** Function: get_int
 ** Description: gets integer from user
 ** Parameters: int address for suit
 ** Pre-Conditions: expects to get suit from user
 ** Post-Conditions: int is updated with desired suit
 **********************************************************/

void Player::get_int(int& num) {
	bool bad = 1;
	int max = 3;
	int min = 0;
	string str;
	cout << endl << "Enter 0 for clubs." << endl;
	cout << "Enter 1 for diamonds." << endl;
	cout << "Enter 2 for hearts." << endl;
	cout << "Enter 3 for spades." << endl;
	while(bad) {
		cout << "Choose a suit: ";
		getline(cin, str);
		for(int i = 0; i < str.length(); i++) {
			/* Checks for invalid characters */
			if((int)str[i] < 48 || (int)str[i] > 57) {
				cout << "Invalid input." << endl;
				break;
			}
			/* Checks that number is in range */
			else if(i == str.length() - 1) {
				num = stod(str);
				if(num > max || num < min) {
					cout << "Enter a number between " << min << " and " 
						 << max << "." << endl;
					break;
				}
				/* Valid input*/
				else {
					bad = 0;
					break;
				}
			}
		}
	}
}