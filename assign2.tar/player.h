#ifndef PLAYER
#define PLAYER

#include "./hand.h"

#include <string>

using std::string;

class Player {

private:
	Hand hand;
	string name;
public:
// must have constructors, destructor, accessor methods, and mutator methods
	Player();
	~Player();

	Hand get_hand();

	string get_name();
	void set_name(string);

	void print_hand();
	void add_card(Card);
	int turn(Card&);
	bool can_play(Card, Card&);
	void play_card(Card, Card&);
	void get_suit(Card&);
	void get_int(int&);
};

#endif