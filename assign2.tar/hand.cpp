#include "./hand.h"
#include "./card.h"

#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::cin;
using std::string;

/**********************************************************
 ** Function: Hand constructor
 ** Description: constructs a hand object
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: creates hand object
 **********************************************************/

Hand::Hand() {
	cards = nullptr;
	n_cards = 0;
	cout << "Hand created" << endl;
}

/**********************************************************
 ** Function: Hand destructor
 ** Description: destroys a hand
 ** Parameters: none
 ** Pre-Conditions: there is dynamic memory to delete
 ** Post-Conditions: destroys hand object
 **********************************************************/

Hand::~Hand() {
	delete [] cards;
	cards = nullptr;
}

/**********************************************************
 ** Function: Hand copy constructor
 ** Description: copies hand into empty hand
 ** Parameters: hand address
 ** Pre-Conditions: uninitialized hand
 ** Post-Conditions: contents of hand copied
 **********************************************************/

Hand::Hand(const Hand& hand) {
	this -> n_cards = hand.n_cards;
	this -> cards = new Card[n_cards];
	for (int i = 0; i < n_cards; i++) {
		this -> cards[i] = hand.cards[i];
	}
}

/**********************************************************
 ** Function: Hand assignment operator overload
 ** Description: copies hand into initialized hand
 ** Parameters: hand address
 ** Pre-Conditions: initialized hand
 ** Post-Conditions: deletes contents then copies in new contents
 **********************************************************/

Hand& Hand::operator=(const Hand& hand) {
	if (this != &hand) {
		this -> n_cards = hand.n_cards;
		delete [] this -> cards;
		cards = new Card[n_cards];
		for (int i = 0; i < n_cards; i++) {
			this -> cards[i] = hand.cards[i];
		}
	}
	return *this;
}

/**********************************************************
 ** Function: get_card
 ** Description: returns card at given index
 ** Parameters: card index
 ** Pre-Conditions: cards contains element at i
 ** Post-Conditions: returns card at i
 **********************************************************/

Card Hand::get_card(int i) {
	return cards[i];
}

/**********************************************************
 ** Function: get_n_cards
 ** Description: returns the number of cards in hand
 ** Parameters: none
 ** Pre-Conditions: expects int
 ** Post-Conditions: returns n_cards
 **********************************************************/

int Hand::get_n_cards() {
	return n_cards;
}

/**********************************************************
 ** Function: add_card
 ** Description: adds card to hand and increments n_cards
 ** Parameters: card to add
 ** Pre-Conditions: n_cards is correct
 ** Post-Conditions: replaces cards with 1 larger array and
 					 increments n_cards
 **********************************************************/

void Hand::add_card(Card card) {
	Card* temp = new Card[n_cards + 1];
	if(n_cards != 0) {
		for (int i = 0; i < n_cards; i++) {
			temp[i] = cards[i];
		}
	}
	delete [] cards;
	cards = temp;
	cards[n_cards] = card;
	n_cards++;
}

/**********************************************************
 ** Function: print_hand
 ** Description: outputs cards in hand
 ** Parameters: none
 ** Pre-Conditions: n_cards is correct
 ** Post-Conditions: outputs cards with a space between
 **********************************************************/

void Hand::print_hand() {
	for (int i = 0; i < n_cards; i++) {
		cards[i].print_card();
		cout << " ";
	}
	cout << endl;
}

/**********************************************************
 ** Function: remove_card
 ** Description: removes card and given index and 
 				 decrements n_cards
 ** Parameters: played card
 ** Pre-Conditions: n_cards is correct
 ** Post-Conditions: cards is replaced with 1 smaller array
 					 and n_cards is decremented
 **********************************************************/

Card Hand::remove_card(int played) {
	Card card = cards[played];
	Card* temp = new Card[n_cards - 1];
	if(n_cards > 1) {
		int j = 0;
		for (int i = 0; i < n_cards; i++) {
			if (i != played) {
				temp[j] = cards[i];
				j++;
			}
		}
	}
	delete [] cards;
	cards = temp;
	n_cards--;
	return card;
}

/**********************************************************
 ** Function: can_play
 ** Description: compares cards in hand to pile
 ** Parameters: pile
 ** Pre-Conditions: n_cards is correct
 ** Post-Conditions: returns is hand contains a playable card
 **********************************************************/

bool Hand::can_play(Card pile) {
	int pile_suit = pile.get_suit();
	int pile_rank = pile.get_rank();

	for (int i = 0; i < n_cards; i++) {
		int card_rank = cards[i].get_rank();
		if (card_rank == pile_rank || card_rank == 8) {
			return 1;
		}
		int card_suit = cards[i].get_suit();
		if (card_suit == pile_suit) {
			return 1;
		}
	}
	return 0;
}

/**********************************************************
 ** Function: card_to_play
 ** Description: gets card to play from user
 ** Parameters: none
 ** Pre-Conditions: cards is initialized
 ** Post-Conditions: returns card user wants to play
 **********************************************************/

Card Hand::card_to_play() {
	int index = 0;
	get_int(index);
	return cards[index - 1];
}

/**********************************************************
 ** Function: get_int
 ** Description: gets integer from user
 ** Parameters: int address
 ** Pre-Conditions: n_cards is correct and card index is expected
 ** Post-Conditions: returns card index from user
 **********************************************************/

void Hand::get_int(int& num) {
	bool bad = 1;
	int max = n_cards;
	int min = 1;
	string str;
	cout << endl << "Enter 1 for leftmost card." << endl;
	cout << "Enter 2 for second card." << endl;
	cout << "Pattern continues" << endl;
	while(bad) {
		cout << "Select a card to play: ";
		getline(cin, str);
		for(int i = 0; i < str.length(); i++) {
			/* Checks for invalid characters */
			if((int)str[i] < 48 || (int)str[i] > 57) {
				cout << "Invalid input." << endl;
				break;
			}
			/* Checks that number is in range */
			else if(i == str.length() - 1) {
				num = stod(str);
				if(num > max || num < min) {
					cout << "Enter a number between " << min << " and " 
						 << max << "." << endl;
					break;
				}
				/* Valid input*/
				else {
					bad = 0;
					break;
				}
			}
		}
	}
}