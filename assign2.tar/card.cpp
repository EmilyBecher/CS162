#include "./card.h"

#include <iostream>

using std::cout;
using std::endl;

/**********************************************************
 ** Function: Card Constructor
 ** Description: constructs card object
 ** Parameters: none
 ** Pre-Conditions: no parameters
 ** Post-Conditions: card created
 **********************************************************/

Card::Card() {
	rank = 0;
	suit = -1;
}

/**********************************************************
 ** Function: Card Destructor
 ** Description: Destroys card object
 ** Parameters: none
 ** Pre-Conditions: card exists
 ** Post-Conditions: card no longer exists
 **********************************************************/

Card::~Card() {
	
}

/**********************************************************
 ** Function: get_rank
 ** Description: accesses rank value of a card
 ** Parameters: none
 ** Pre-Conditions: card has been initialized
 ** Post-Conditions: returns rank as int
 **********************************************************/

int Card::get_rank() {
	return rank;
}

/**********************************************************
 ** Function: get_suit
 ** Description: accesses suit value of a card
 ** Parameters: none
 ** Pre-Conditions: card has been initialized
 ** Post-Conditions: returns suit as int
 **********************************************************/

int Card::get_suit() {
	return suit;
}

/**********************************************************
 ** Function: set_rank
 ** Description: mutates rank of a card
 ** Parameters: rank
 ** Pre-Conditions: card exists
 ** Post-Conditions: changes rank of card to given rank
 **********************************************************/

void Card::set_rank(int rank) {
	this -> rank = rank;
}

/**********************************************************
 ** Function: set_suit
 ** Description: mutates suit of a card
 ** Parameters: suit
 ** Pre-Conditions: card exists
 ** Post-Conditions: changes suit of card to given suit
 **********************************************************/

void Card::set_suit(int suit) {
	this -> suit = suit;
}

/**********************************************************
 ** Function: print_card
 ** Description: outputs the rank and suit of a card
 ** Parameters: none
 ** Pre-Conditions: card exists
 ** Post-Conditions: rank and suit are printed in the form 0S
 **********************************************************/

void Card::print_card() {
	if (rank == 0 && suit == -1) {
		return;
	}
	switch(rank) {
		case 13:
			cout << "K";
			break;
		case 12:
			cout << "Q";
			break;
		case 11:
			cout << "J";
			break;
		case 1:
			cout << "A";
			break;
		default:
			cout << rank;
	}
	switch(suit) {
		case 0:
			cout << "C";
			break;
		case 1:
			cout << "D";
			break;
		case 2:
			cout << "H";
			break;
		default:
			cout << "S";
	}
}
