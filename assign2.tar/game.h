#ifndef GAME
#define GAME

#include "./deck.h"
#include "./game.h"
#include "./player.h"

class Game {
private:
	Deck cards;
	Player player[2];
	Card pile;
public:

	Game();
	~Game();

	Deck get_deck();
	void set_deck(Deck);

	Player get_player(int);
	void set_player(Player, int);

	Card get_pile();
	void set_pile(Card);

	void set_up();
	int play();

	void deal();
	int play_turn(int);
};

#endif