/**********************************************************
 ** Program: crazy8s.cpp
 ** Author: Emily Becher
 ** Date: 04/24/2021
 ** Description: crazy eights game where the user plays computer
 ** Inputs: cin (card to play, desired suit, play again)
 ** Outputs: instructions and game play to console
 **********************************************************/

#include "./game.h"

#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::cin;
using std::string;

void get_bool(bool&);

int main() {
	srand(time(nullptr));

	//Welcome
	cout << endl << "Welcome to Crazy Eights!" << endl;
	cout << "You are going to play against the computer" << endl << endl;

	//play game
	bool run = 1;

	while(run) {
		Game game;
		game.set_up();
		int result = 0;
		while (result == 0) {
			result = game.play();
			switch (result) {
				case 1:
					cout << "You won!" << endl;
					break;
				case 2:
					cout << "You lost." << endl;
					break;
				case 3:
					cout << "You tied." << endl;
			}
		}
		get_bool(run);
	}

	return 0;
}

/**********************************************************
 ** Function: get_bool
 ** Description: gets yes/no answer from user
 ** Parameters: bool address
 ** Pre-Conditions: need to ask user if they want to play again
 ** Post-Conditions: bool is set to 1 or 0
 **********************************************************/

void get_bool(bool& again) {
	string str;
	bool bad = 1;
	cout << "Do you want to play again?: ";
	while(bad) {
		getline(cin, str);
		if(str.length() != 1) {
			cout << "Enter y or n: ";
		}
		/* True cases*/
		else if(str == "y" || str == "Y" || str == "1") {
			again = 1;
			bad = 0;
		}
		/* False cases*/
		else if(str == "n" || str == "N" || str == "0") {
			again = 0;
			bad = 0;
		}
		else {
			cout << "Enter y or n: ";
		}
	}
}