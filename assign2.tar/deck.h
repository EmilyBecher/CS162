#ifndef DECK
#define DECK

#include "./card.h"
#include <stdlib.h>

class Deck {

private:
	Card* cards;
	int n_cards;

public:

	Deck();
	~Deck();

	Card get_card(int);
	void set_card(Card, int);

	int get_n_cards();

	void shuffle();

	void print_deck();

	Card remove_card();
};

#endif