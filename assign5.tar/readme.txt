Emily Becher
CS162 Assignment 5
6-6-2021

This program implements an application of the Linked_List class.

The Linked_List class includes the functionality of push_front, push_back,
insert, sort_ascending, sort_descending, reverse, count_primes, clear, and print.

push_front inserts a new node at the front of the list.
push_back inserts a new node at the end of the list.
insert places a new node at a given location.
	A location of three would make the new node the third node in the list.
sort_ascending uses a recursives merge sort function.
sort_descending calls sort_ascending and then reverse.
reverse reverses the order of nodes in the list.
count_primes returns the number of primes where primes are greater than 0.
clear deletes the list.
print outputs the list.