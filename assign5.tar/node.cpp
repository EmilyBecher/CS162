#include "./node.h"

/*********************************************************
 ** Function: Node default constructor
 ** Description: constructs node without 0 val
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: node created
 *********************************************************/

Node::Node() {
	val = 0;
	next = nullptr;
}

/*********************************************************
 ** Function: Node parameterized constructor
 ** Description: constructs node of provided value
 ** Parameters: int
 ** Pre-Conditions: none
 ** Post-Conditions: node created with given val
 *********************************************************/

Node::Node(int val) {
	this -> val = val;
	next = nullptr;
}

/*********************************************************
 ** Function: Node copy constructor
 ** Description: copies contents of given Node
 ** Parameters: Node address
 ** Pre-Conditions: constructed Node is empty
 ** Post-Conditions: new copy is created
 *********************************************************/

Node::Node(Node& other) {
	this -> val = other.val;
	this -> next = other.next;
}

/*********************************************************
 ** Function: Node assignment operator overload
 ** Description: copies contents of given Node
 ** Parameters: Node address
 ** Pre-Conditions: Node has been created
 ** Post-Conditions: Node contains contents of given Node
 *********************************************************/

Node& Node::operator=(Node& other) {
	this -> val = other.val;
	if (this -> next != nullptr) {
		delete next;
	}
	this -> next = other.next;
	return *this;
}
