#ifndef LIST
#define LIST

#include "./node.h"

#include <iostream>
using namespace std;

class Linked_List {
private:
	unsigned int length;
	Node *head;
	
public:
	/*constructor/destructor*/
	Linked_List();
	~Linked_List();

	int get_length();
	void print();
	void clear();

	/*Add Nodes to list*/
	unsigned int push_front(int);
	unsigned int push_back(int);
	unsigned int insert(int, unsigned int);

	void sort_ascending();
	void merge_sort(Node*&);
	void split(Node*, Node*&, Node*&);
	Node* merge_list(Node*, Node*);

	void sort_descending();
	Node* reverse();

	int count_primes();
	bool prime(int);
};

#endif