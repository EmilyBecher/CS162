#ifndef NODE
#define NODE

#include <iostream>
using namespace std;

class Node {
public:
	int val;
	Node *next;

	//constructors
	Node();
	Node(int);
	Node(Node& other);
	Node& operator=(Node& other);
};

#endif