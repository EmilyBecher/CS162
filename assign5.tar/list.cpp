#include "./list.h"

/*********************************************************
 ** Function: Linked list constructor
 ** Description: constructs empty list
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: empty list is created
 *********************************************************/

Linked_List::Linked_List() {
	length = 0;
	head = nullptr;
}

/*********************************************************
 ** Function: Linked list destructor
 ** Description: destroys list and nodes
 ** Parameters: none
 ** Pre-Conditions: linked list exists
 ** Post-Conditions: dynamic memory is freed
 *********************************************************/

Linked_List::~Linked_List() {
	/*Check there is dynamic memory*/
	if (head != nullptr) {
		int num = length;
		Node* temp = new Node;
		while (num > 0) {
			temp -> next = head;
			for (int i = 0; i < num - 1; i++) {
				temp -> next = temp -> next -> next;
			}
			delete temp -> next;
			num--;
		}
		delete temp;
	}
}

/*********************************************************
 ** Function: get length
 ** Description: returns length member
 ** Parameters: none
 ** Pre-Conditions: length exists
 ** Post-Conditions: length is returned
 *********************************************************/

int Linked_List::get_length() {
	return length;
}

/*********************************************************
 ** Function: print
 ** Description: outputs the list
 ** Parameters: none
 ** Pre-Conditions: list exists
 ** Post-Conditions: list is outputted to console
 *********************************************************/

void Linked_List::print() {
	if (head != nullptr) {
		cout << "Linked_List: ";
		Node* temp;
		temp = head;
		for (unsigned int i = 0; i < length; i++) {
			cout << temp  -> val << " ";
			temp = temp -> next;
		}
		cout << endl;
	}
	else {
		cout << "The list is empty" << endl;
	}
}

/*********************************************************
 ** Function: clear
 ** Description: deletes list, but doesn't destroy it
 ** Parameters: none
 ** Pre-Conditions: length is correct
 ** Post-Conditions: list is reset
 *********************************************************/

void Linked_List::clear() {
	if (head != nullptr) {
		int num = length;
		Node* temp = new Node;
		while (num > 0) {
			temp -> next = head;
			for (int i = 0; i < num - 1; i++) {
				temp -> next = temp -> next -> next;
			}
			delete temp -> next;
			num--;
		}
		delete temp;
		head = nullptr;
		length = 0;
	}
}

/*********************************************************
 ** Function: push front
 ** Description: inserts node at front of list
 ** Parameters: val of new node
 ** Pre-Conditions: needs parameterized node constructor
 ** Post-Conditions: node is added to list
 *********************************************************/

/*I'm not sure why these functions returned length*/

unsigned int Linked_List::push_front(int val) {
	Node* temp = new Node(val);
	temp -> next = head; //points to previous front
	head = temp; 
	return ++length;
}

/*********************************************************
 ** Function: push back
 ** Description: inserts node at end of list
 ** Parameters: value of new node
 ** Pre-Conditions: length is accurate
 ** Post-Conditions: node is added to list
 *********************************************************/

unsigned int Linked_List::push_back(int val) {
	Node* temp;
	temp = head;
	/*find last element*/
	for (unsigned int i = 0; i < length - 1; i++) {
		temp = temp -> next;
	}
	Node* add = new Node(val);
	temp -> next = add; //last element points to new node
	return ++length;
}

/*********************************************************
 ** Function: insert
 ** Description: inserts new node at given location
 				 3 means third element
 ** Parameters: val and index
 ** Pre-Conditions: length is accurate
 ** Post-Conditions: node is added to list
 *********************************************************/

unsigned int Linked_List::insert(int val, unsigned int index) {
	if (index <= length + 1) {
		Node* temp;
		temp = head;
		for (unsigned int i = 0; i < index - 2; i++) {
			temp = temp -> next;
		}
		Node* add = new Node(val);
		add -> next = temp -> next;
		temp -> next = add;
		return ++length;
	}
	return length;
}

/*********************************************************
 ** Function: sort ascending
 ** Description: sorts lists least to greatest
 ** Parameters: none
 ** Pre-Conditions: list exists
 ** Post-Conditions: list is sorted
 *********************************************************/

void Linked_List::sort_ascending() {
	if (head != nullptr) {
		merge_sort(head);
	}
}

/*********************************************************
 ** Function: merge sort
 ** Description: executes the merge sort algorithm
 ** Parameters: Node pointer address
 ** Pre-Conditions: list exists
 ** Post-Conditions: list is sorted
 *********************************************************/

void Linked_List::merge_sort(Node*& begin) {
	Node* start = begin;
	Node* left;
	Node* right;
 	/*Base case: one or zero nodes*/
	if(start == NULL || start -> next == NULL) {
		return;
	}
	split(start, left, right); 
	merge_sort(left);
	merge_sort(right);
	begin = merge_list(left, right);
}

/*********************************************************
 ** Function: split
 ** Description: splits list in half
 ** Parameters: Node*, Node*&, Node*&
 ** Pre-Conditions: left and right are correct
 ** Post-Conditions: left and right are heads of two halves
 *********************************************************/

void Linked_List::split(Node* begin, Node*& left, Node*& right) {
	/*move ahead twice as fast so when ahead reaches the
	  end behind is in the middle*/
	Node* behind = begin;
	Node* ahead = begin -> next;
	while(ahead != NULL) {
		ahead = ahead -> next;
		if(ahead != NULL) { /*makes sure ahead doesn't read too far*/
			behind = behind -> next;
			ahead = ahead -> next;
		}
	}
	left = begin;
	right = behind -> next;
	behind -> next = NULL;
}

/*********************************************************
 ** Function: merge list
 ** Description: combines two lists
 ** Parameters: heads of two lists
 ** Pre-Conditions: lists are unique
 ** Post-Conditions: lists are combined and new_head is returned
 *********************************************************/

Node* Linked_List::merge_list(Node* left, Node* right) { 
	Node* new_head = NULL;
	if(left == NULL) {
		return right;
	}
	if(right == NULL) {
		return left;
	}
   //recursively merge the lists
	if(left -> val <= right -> val) {
		new_head = left;
		new_head -> next = merge_list(left -> next, right);
	} 
	else {
		new_head = right;
		new_head -> next = merge_list(left, right->next);
	}
	return new_head;
}

/*********************************************************
 ** Function:sort descending
 ** Description: sorts the list from greatest to least
 ** Parameters: none
 ** Pre-Conditions: list exists
 ** Post-Conditions: list is sorted
 *********************************************************/

void Linked_List::sort_descending() {
	sort_ascending();
	head = reverse();
}

/*********************************************************
 ** Function: reverse
 ** Description: reverses node order
 ** Parameters: none
 ** Pre-Conditions: list exists
 ** Post-Conditions: list is reversed
 *********************************************************/

Node* Linked_List::reverse() {
	Node* behind;
	Node* end;
	/*Base case: one element left*/
	if (head -> next == nullptr) {
		return head;
	}
	end = head -> next;
	behind = head;
	/*behind always points to end*/
	while (end -> next != nullptr) {
		end = end -> next;
		behind = behind -> next;
	}
	behind -> next = nullptr; /*removes last element*/
	end -> next = reverse();
	return end;
}

/*********************************************************
 ** Function: count primes
 ** Description: returns primes > 0 in list
 ** Parameters: none
 ** Pre-Conditions: list exists
 ** Post-Conditions: returns number of primes (includes duplicates)
 *********************************************************/

int Linked_List::count_primes() {
	int count = 0;
	Node* temp;
	temp = head;
	/*loop through all nodes*/
	while (temp != nullptr) {
		if (temp -> val > 0 && prime(temp -> val) == 1) { /*doesn't call prime if val < 1*/
			count++;
		}
		temp = temp -> next;
	}
	return count;
}

/*********************************************************
 ** Function: prime
 ** Description: checks if num is prime
 ** Parameters: int
 ** Pre-Conditions: num is positive (if not will output 1)
 ** Post-Conditions: returns 1 if prime
 *********************************************************/

bool Linked_List::prime(int num) {
	if (num == 1 || num == 2) {
		return 1;
	}
	for (int i = num - 1; i > 1; i--) {
		if (num % i == 0) {
			return 0;
		}
	}
	return 1;
}
