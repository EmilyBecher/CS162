/******************************************************
** Program: driver.cpp
** Author: Emily Becher
** Date: 6/6/2021
** Description: runs an application of Linked_List where
				user adds ints to the list
** Input: bools and ints
** Output: instructions and results to console
******************************************************/
#include "./node.h"
#include "./list.h"

#include <iostream>
#include <string>
#include <cstring>

using namespace std;

int get_num();
void get_bool(bool&, string);

int main() {
	Linked_List l;
	bool again = true;
	int num;

	while (again) {
		bool add = true;
		l.clear();
		while (add) {
			num = get_num();
			l.push_front(num);
			get_bool(add, "Add another? (y or n): ");
		}
		bool sort;
		get_bool(sort, "Ascending sort? (y or n): ");
		if (sort) {
			l.sort_ascending();
		}
		else {
			l.sort_descending();
		}
		l.print();
		cout << "There are " << l.count_primes() << " primes in the list." << endl;
		get_bool(again, "Create another list? (y or n): ");
	}

	return 0;
}

/*********************************************************
 ** Function: get num
 ** Description: gets and int from user
 ** Parameters: none
 ** Pre-Conditions: int expected
 ** Post-Conditions: returns int (will ignore garbage after int)
 *********************************************************/

int get_num() {
	string str;
	int num;
	cout << "Enter number to add: ";
	while (true) {
		getline(cin, str);
		for (unsigned int i = 0; i < str.length(); i++) {
			if (((int)str[i] < 48 || (int)str[i] > 57) && (int)str[i] != 45) {
				cout << "Enter an integer: ";
				break;
			}
			else {
				num = stod(str);
				return num;
			}
		}
	}
}

/*********************************************************
 ** Function: get bool
 ** Description: gets y or n from user
 ** Parameters: bool address and string prompt
 ** Pre-Conditions: prompt expects y or n
 ** Post-Conditions: var value is updated
 *********************************************************/

void get_bool(bool& var, string prompt) {
	string str;
	cout << prompt;
	while (true) {
		getline(cin, str);
		if (str == "y") {
			var = 1;
			return;
		}
		else if (str == "n") {
			var = 0;
			return;
		}
		cout << "Enter y or n: ";
	}
}