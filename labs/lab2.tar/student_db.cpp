#include <iostream>
#include "student_db.h"
using namespace std;

student* create_student_db(int n){
	student* student_list = new student[n];
	return student_list;
}

void get_student_db_info(student * student_list, int n, fstream & ifile) {
	for(int i = 0; i < n; i++){
		ifile >> student_list[i].id_num;
		ifile >> student_list[i].fname;
		ifile >> student_list[i].lname;
		ifile >> student_list[i].major;
	}
}

void delete_student_db_info(student * student_list){
	delete [] student_list;
}

void id_sort(student * student_list, ofstream & sorted_list, int n) {
	int print = 0;
	int temp = 0;
	sorted_list << "Students by ID Number" << endl;
	while(print < n) {
		int min = 999999999;
		for(int i = 0; i < n; i++) {
			if(student_list[i].id_num > temp && student_list[i].id_num < min) {
				min = student_list[i].id_num;
			}
		}
		temp = min;
		for (int i = 0; i < n; i++) {
			if(student_list[i].id_num == min) {
				sorted_list << student_list[i].id_num << " ";
				sorted_list << student_list[i].fname << " ";
				sorted_list << student_list[i].lname << " ";
				sorted_list << student_list[i].major << endl;
				print++;
			}
		}
	}
	sorted_list << endl;
}

void lname_sort(student * student_list, ofstream & sorted_list, int n) {
	int print = 0;
	int temp = 0;
	sorted_list << "Students by Last Name" << endl;

	while(print < n) {
		int min = 91;
		for(int i = 0; i < n; i++) {
			if(student_list[i].lname.at(0) > temp && student_list[i].lname.at(0) < min) {
				min = student_list[i].lname.at(0);
			}
		}
		temp = min;
		for (int i = 0; i < n; i++) {
			if(student_list[i].lname.at(0) == min) {
				sorted_list << student_list[i].lname << " ";
				sorted_list << student_list[i].fname << " ";
				sorted_list << student_list[i].id_num << " ";
				sorted_list << student_list[i].major << endl;
				print++;
			}
		}
	}

	/*for(int i = 0; i < n; i++) {
		char c = student_list[i].lname.at(0);
		cout << c << endl;
		int j = c;
		cout << j << endl;
		sorted_list << student_list[i].lname << " ";
		sorted_list << student_list[i].fname << " ";
		sorted_list << student_list[i].id_num << " ";
		sorted_list << student_list[i].major << endl;
	}*/
}