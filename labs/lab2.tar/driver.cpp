#include <iostream>
#include "student_db.h"

using namespace std;

int main() {

	fstream unsorted_info("inputs.txt", ios::in);
	ofstream sorted_info("sorted_lists.txt", ios::out);
	if(unsorted_info.fail()) {//check that file exists
		cout << "Error opening file." << endl;
		sorted_info << "Failed to open file." << endl;
	}
	else {
		int n;
		unsorted_info >> n;
		student* student_list = create_student_db(n);
		get_student_db_info(student_list, n, unsorted_info);
		//sort and write out
		id_sort(student_list, sorted_info, n);
		lname_sort(student_list, sorted_info, n);
		delete_student_db_info(student_list);
	}
	unsorted_info.close();
	sorted_info.close();

	return 0;
}