#include "tips.h"
#include <iostream>

using namespace std;

int main () {
	float tip_a = 0;
	float tip_b = 0;

	Tips a;
	Tips b(0.1);

	tip_a = a.computeTip(100, .15);
	tip_b = b.computeTip(100, .15);

	cout << "Default Tip: " << tip_a << endl;
	cout << "0.1 Tax Rate Tip: " << tip_b << endl; 

	return 0;
}