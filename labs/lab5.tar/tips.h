#ifndef TIPS
#define TIPS

class Tips {
private:
	float tax_rate;

public:
	//default constructor
	Tips();

	//Parameterized constructor
	Tips(float);

	//Only Function
	float computeTip(float, float);
};

#endif