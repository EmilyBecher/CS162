#include "tips.h"

Tips::Tips() {
	tax_rate = 0.065;
}

Tips::Tips(float rate) {
	tax_rate = rate;
}

float Tips::computeTip(float bill, float tip_rate) {
	float meal_cost = 0;
	float tip = 0;

	meal_cost = bill / (1 + tax_rate);

	tip = meal_cost * tip_rate;

	return tip;
}

