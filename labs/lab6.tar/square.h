#ifndef SQUARE
#define SQUARE

#include "rectangle.h"

class Square : public Rectangle {
public:
	Square();
	Square(string, float);

	~Square();

	void set_width(float);
	void set_height(float);
};

#endif