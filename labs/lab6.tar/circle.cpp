#include "circle.h"

Circle::Circle() {
	set_name("Circle");
	radius = 0;
}

Circle::Circle(string color, float radius) {
	try {
		if (radius <= 0) {
			throw -1;
		}
	} 
	catch (int e) {
		cout << endl << "Since you don't know how circles work I chose the radius for you." << endl;
		radius = 5;
	}
	set_color(color);
	set_name("Circle");
	this -> radius = radius;
}

Circle::~Circle() {

}

float Circle::get_radius() {
	return radius;
}

void Circle::set_radius(float radius) {
	try {
		if (radius <= 0) {
			throw -1;
		}
		this -> radius = radius;
	}
	catch (int e) {
		cout << "nope" << endl;
	}
}

float Circle::area() {
	return 3.14 * radius * radius;
}