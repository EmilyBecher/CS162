#ifndef RECT
#define RECT

#include "shape.h"

#include <iostream>

using namespace std;

class Rectangle : public Shape {
private:
	float width;
	float height;

public:
	Rectangle();
	Rectangle(string, float, float);

	~Rectangle();

	float get_width();
	float get_height();

	void set_width(float);
	void set_height(float);

	float area() const;

	void print_shape_info(Rectangle &);
};

bool operator> (const Rectangle &, const Rectangle &);
bool operator< (const Rectangle &, const Rectangle &);

#endif