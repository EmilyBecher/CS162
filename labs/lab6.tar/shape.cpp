#include "shape.h"

#include <iostream>

using namespace std;

Shape::Shape() {
	name = " ";
	color = " ";
}

Shape::Shape(string name, string color) {
	this -> name = name;
	this -> color = color;
}

Shape::~Shape() {
	
}

string Shape::get_name() {
	return name;
}

string Shape::get_color() {
	return color;
}

void Shape::set_name(string name) {
	this -> name = name;
}

void Shape::set_color(string color) {
	this -> color = color;
}

float Shape::area() {
	return 0;
}

void Shape::print_shape_info(Shape & shape) {
	cout << endl << "Name: " << shape.get_name() << endl;
	cout << "Color: " << shape.get_color() << endl;
	cout << "Area: " << shape.area() << endl;
}