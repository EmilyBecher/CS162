#include "shape.h"
#include "circle.h"
#include "rectangle.h"
#include "square.h"

#include <iostream>

using namespace std;

int main() {

	Shape a;
	Shape b("Shape", "blue");

	a.set_name("Shape");
	a.set_color("red");

	/*cout << "Name is " << a.get_name() << " and color is " << a.get_color() << endl;
	cout << "Name is " << b.get_name() << " and color is " << b.get_color() << endl;
	*/

	Circle c1;
	Circle c2("green", 1);

	c1.set_color("yellow");
	c1.set_radius(10);

	/*cout << endl << "Name: " << c1.get_name() << endl;
	cout << "Color: " << c1.get_color() << endl;
	cout << "Area: " << c1.area() << endl;*/

	c1.print_shape_info(c1);

	/*cout << endl << "Name: " << c2.get_name() << endl;
	cout << "Color: " << c2.get_color() << endl;
	cout << "Area: " << c2.area() << endl;*/

	c2.print_shape_info(c2);

	Rectangle r1;
	Rectangle r2("white", 5, 6);

	r1.set_color("black");
	r1.set_width(2);
	r1.set_height(3);

	/*cout << endl << "Name: " << r1.get_name() << endl;
	cout << "Color: " << r1.get_color() << endl;
	cout << "Area: " << r1.area() << endl;*/

	r1.print_shape_info(r1);

	/*cout << endl << "Name: " << r2.get_name() << endl;
	cout << "Color: " << r2.get_color() << endl;
	cout << "Area: " << r2.area() << endl;*/

	r2.print_shape_info(r2);

	Square s1;
	Square s2("purple", 4);

	s1.set_color("orange");
	s1.set_height(7);

	/*cout << endl << "Name: " << s1.get_name() << endl;
	cout << "Color: " << s1.get_color() << endl;
	cout << "Area: " << s1.area() << endl;*/

	s1.print_shape_info(s1);

	/*cout << endl << "Name: " << s2.get_name() << endl;
	cout << "Color: " << s2.get_color() << endl;
	cout << "Area: " << s2.area() << endl;*/

	s2.print_shape_info(s2);	

	if (r1 > r2) {
		cout << r1.get_color() << " " << r1.get_name() << " is larger" << endl;
	}
	else if (r1 < r2) {
		cout << r2.get_color() << " " << r2.get_name() << " is larger" << endl;
	}
	else {
		cout << "The rectangles are the same size" << endl;
	}

	cout << "Exception test:" << endl;

	Rectangle r3("black", -3, 0);
	Square s3("blue", 0);
	Circle c3("green", -134);

	c3.set_radius(0);
	r3.set_height(-3);
	s3.set_width(-5);

	r3.print_shape_info(r3);
	s3.print_shape_info(s3);
	c3.print_shape_info(c3);

	return 0;
}