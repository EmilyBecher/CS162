#include "square.h"

Square::Square() {
	set_name("Square");
}

Square::Square(string color, float side) {
	set_name("Square");
	set_color(color);
	try {
		if (side <= 0) {
			throw -1;
		}
	} 
	catch (int e) {
		cout << endl << "Since you don't know how shapes work I chose side lengths for you." << endl;
		side = 5;
	}
	set_width(side);
}

Square::~Square() {

}

void Square::set_width(float side) {
	Rectangle::set_width(side);
	Rectangle::set_height(side);
}

void Square::set_height(float side) {
	Rectangle::set_width(side);
	Rectangle::set_height(side);
}