#ifndef SHAPE
#define SHAPE

#include <iostream>

using namespace std;

class Shape {
private:
	string name;
	string color;

public:
	Shape();
	Shape(string, string);

	~Shape();

	string get_name();
	string get_color();

	void set_name(string);
	void set_color(string);

	virtual float area();

	virtual void print_shape_info(Shape &);
};

#endif