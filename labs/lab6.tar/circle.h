#ifndef CIRCLE
#define CIRCLE

#include "shape.h"

#include <iostream>

using namespace std;

class Circle : public Shape {
private:
	float radius;

public:
	Circle();
	Circle(string, float);

	~Circle();

	float get_radius();

	void set_radius(float);

	float area();
};

#endif