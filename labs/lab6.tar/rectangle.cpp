#include "rectangle.h"

#include <iostream>

using namespace std;

Rectangle::Rectangle() {
	set_name("Rectangle");
	width = 0;
	height = 0;
}

Rectangle::Rectangle(string color, float width, float height) {
	set_name("Rectangle");
	set_color(color);
	try {
		if (width <= 0 || height <= 0) {
			throw -1;
		}
	} 
	catch (int e) {
		cout << endl << "Since you don't know how shapes work I chose side lengths for you." << endl;
		width = 5;
		height = 5;
	}
	this -> width = width;
	this -> height = height;
}

Rectangle::~Rectangle() {

}

float Rectangle::get_width() {
	return width;
}

float Rectangle::get_height() {
	return height;
}

void Rectangle::set_width(float width) {
		try {
		if (width <= 0) {
			throw -1;
		}
		this -> width = width;
	}
	catch (int e) {
		cout << "nope" << endl;
	}
}

void Rectangle::set_height(float height) {
	try {
		if (height <= 0) {
			throw -1;
		}
		this -> height = height;
	}
	catch (int e) {
		cout << "nope" << endl;
	}
}

float Rectangle::area() const{
	return width * height;
}

bool operator> (const Rectangle & r1, const Rectangle & r2) {
	return (r1.area() > r2.area());
}

bool operator< (const Rectangle & r1, const Rectangle & r2) {
	return (r1.area() < r2.area());
}

void Rectangle::print_shape_info(Rectangle & shape) {
	cout << endl << "Name: " << shape.get_name() << endl;
	cout << "Color: " << shape.get_color() << endl;
	cout << "Area: " << shape.area() << endl;
}