#include "./vector.hpp"
#include <vector>
#include <iostream>

//don't use 'usind std::vector'
using std::cout;
using std::endl;

int main() {
	vector<int> v;	//our vector class
	std::vector<int> stdv; //standard vector
	vector<int> v2;

	//compare operation
	v.push_back(23);
	v2.push_back(35);
	stdv.push_back(23);

	vector<int> v1 = v;

	v.push_back(5);

	cout << "Our vector size: " << v.size() << endl;
	cout << "Our vector cap: " << v. capacity() << endl;
	cout << "STL vector size: " << stdv.size() << endl;
	cout << "STL vector cap: " << stdv.capacity() << endl;
	cout << "Our copied vector size: " << v1.size() << endl;
	cout << "Our copied vector cap: " << v1.capacity() << endl;
	cout << "Third vector size: " << v2.size() << endl;
	cout << "Third vector cap: " << v2.capacity() << endl;

	int num2 = v2[0];
	cout << "Before operator=: " << num2 << endl;

	v2 = v;

	num2 = v[0];
	cout << "The first element in our vector: " << num2 << endl;

	num2 = v.at(0);
	cout << "After operator=: " << num2 << endl;

	int num = v.at(1);
	cout << "The second element in our vector: " << num << endl;

	return 0;
}