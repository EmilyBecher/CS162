#include <stdlib.h>
#include <iostream>

using std::cerr;
using std::endl;

template <class T>
class vector {
private:
	T *v;
	int s;
	int c;

public:
	vector() {
		s = 0;
		c = 0;
		v = nullptr;
	}

	vector(vector<T> &other) {
		c = other.c;
		s = other.s;
		v = new T[c];
		for (int i = 0; i < s - 1; i++) {
			v[i] = other.v[i];
		}
	}

	void operator=(vector<T> &other) {
		if (this != &other) {
			c = other.c;
			s = other.s;
			delete [] v;
			v = new T[c];
			for (int i = 0; i < s - 1; i++) {
				v[i] = other.v[i];
			}
		}
	}

	~vector() {
		delete [] v;
	}

	int size() {
		return s;
	}

	int capacity() {
		return c;
	}

	void push_back(T ele) {
		if (s + 1 >= c) {
			resize();
		}
		v[s] = ele;
		s++;
	}

	T& operator[](int i) {
		return v[i];
	}

	T& at(int i) {
		if (i < s) {
			return v[i];
		}
		cerr << "Out of range" << endl;
		T none;
		return none;
	}

	void resize() {
		c += 20;
		T* temp;
		temp = new T[c];
		for (int i = 0; i < s - 1; i++) {
			temp[i] = v[i];
		}
		delete [] v;
		v = temp;
		temp = nullptr;
	}
};