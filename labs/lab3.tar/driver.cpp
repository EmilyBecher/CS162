#include "card.h"
#include "deck.h"

#include <iostream>

using std::cout;
using std::endl;

int main() {
	srand(time(NULL));

	Deck d1;
	d1.print_deck();

	cout << endl << "Shuffled Deck:" << endl;

	d1.shuffle();
	d1.print_deck();

	return 0;
}