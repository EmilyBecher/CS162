#include "./card.h"

#include <iostream>
#include <string>

using std::string;
using std::cout;
using std::endl;

Card::Card() {
	rank = 0;
	suit = " ";
}

Card::Card(int n, string str) {
	rank = n;
	suit = str;
}


int Card::get_rank() {
	return rank;
}

string Card::get_suit() {
	return suit;
}

void Card::set_rank(int rank) {
	this -> rank = rank;
}

void Card::set_suit(string suit) {
	this -> suit = suit;
}

void Card::print_card() {
	switch(rank) {
		case 13:
			cout << "King of " << suit << endl;
			break;
		case 12:
			cout << "Queen of " << suit << endl;
			break;
		case 11:
			cout << "Jack of " << suit << endl;
			break;
		case 1:
			cout << "Ace of " << suit << endl;
			break;
		default:
			cout << rank << " of " << suit << endl;
	}
}