#ifndef CARD
#define CARD

#include <string>

using std::string;

class Card {

private:
	int rank; //1-13
	string suit; 

public:

	Card();
	Card(int, string);

	int get_rank();
	string get_suit();

	void set_rank(int);
	void set_suit(string);

	void print_card();

};

#endif

