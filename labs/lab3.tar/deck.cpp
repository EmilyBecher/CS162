#include "./deck.h"

using std::rand;

Deck::Deck() {
	for(int i = 0; i < 52; i++) {
		int n = i % 13 + 1; //counts from 1-13 then repeats
		cards[i].set_rank(n);
		if (i < 13) {
			cards[i].set_suit("diamonds");
		}
		else if(i < 26) {
			cards[i].set_suit("spades");
		}
		else if(i < 39) {
			cards[i].set_suit("hearts");
		}
		else {
			cards[i].set_suit("clubs");
		}
	}
}

Card Deck::get_card(int i) {
	return cards[i];
}

void Deck::set_card(Card card, int i) {
	cards[i] = card;
}

void Deck::shuffle() {
	for (int i = 0; i < 52; i++) {
		int swap_1 = rand() % 52;
		int swap_2 = rand() % 52;
		Card temp = cards[swap_1];
		cards[swap_1] = cards[swap_2];
		cards[swap_2] = temp;
	}	
}

void Deck::print_deck() {
	for (int i = 0; i < 52; i++) {
		cards[i].print_card();
	}
}