#ifndef DECK
#define DECK

#include "card.h"

#include <stdlib.h>

class Deck {

private:
	Card cards[52];
	//int n_cards;

public:

	Deck();

	Card get_card(int);

	void set_card(Card, int);

	void shuffle();

	void print_deck();

};

#endif