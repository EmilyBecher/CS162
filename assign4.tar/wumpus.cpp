#include "./wumpus.h"

/**********************************************************
 ** Function: wumpus constructor
 ** Description: constructs a wumpus
 ** Parameters: none
 ** Pre-Conditions: event class is included
 ** Post-Conditions: wumpus is created
 *********************************************************/

Wumpus::Wumpus() {
	set_symbol('w');
	set_message("You smell a terrible stench");
}

/**********************************************************
 ** Function: wumpus copy constructor
 ** Description: copies wumpus into new wumpus
 ** Parameters: wumpus address
 ** Pre-Conditions: new wumpus is uninitialized
 ** Post-Conditions: new wumpus contains copied contents
 *********************************************************/

Wumpus::Wumpus(Wumpus& wumpus) {
	set_symbol(wumpus.get_symbol());
	set_message(wumpus.get_message());
}

/**********************************************************
 ** Function: wumpus operator= overload
 ** Description: copies wumpus into existing wumpus
 ** Parameters: wumpus address
 ** Pre-Conditions: wumpus is initialized
 ** Post-Conditions: wumpus contains copied contents
 *********************************************************/

void Wumpus::operator=(Wumpus& wumpus) {
	set_symbol(wumpus.get_symbol());
	set_message(wumpus.get_message());
}

/**********************************************************
 ** Function: action
 ** Description: outputs action and returns action value
 ** Parameters: none
 ** Pre-Conditions: adventurer is in the room
 ** Post-Conditions: message is outputted and 1 is returned so
 					 cave knows the adventurer died
 *********************************************************/

int Wumpus::action() {
	cout << "You were eaten" << endl;
	return 1;
}

/**********************************************************
 ** Function: percept
 ** Description: outputs message
 ** Parameters: none
 ** Pre-Conditions: adventurer is in adjacent room
 ** Post-Conditions: percept is outputted to console
 *********************************************************/

void Wumpus::percept() {
	cout << get_message() << endl;
}