#include "./cave.h"

/**********************************************************
 ** Function: Cave constructor
 ** Description: constructs default cave
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: cave is created
 *********************************************************/

Cave::Cave() {
	grid_size = 5;
	debug = true;
	gold = false;
	arrows = 3;
	dead_wumpus = false;
	rooms.resize(grid_size);
	for (int i = 0; i < grid_size; i++) {
		rooms[i].resize(grid_size);
	}
}

/**********************************************************
 ** Function: parameterized cave constructor
 ** Description: constructs cave
 ** Parameters: int size, bool debug
 ** Pre-Conditions: none
 ** Post-Conditions: cave is created
 *********************************************************/

Cave::Cave(int size, bool debug) {
	grid_size = size;
	this -> debug = debug;
	gold = false;
	arrows = 3;
	dead_wumpus = false;
	rooms.resize(grid_size);
	for (int i = 0; i < grid_size; i++) {
		rooms[i].resize(grid_size);
	}
}

/**********************************************************
 ** Function: play
 ** Description: handles gameplay
 ** Parameters: none
 ** Pre-Conditions: cave is created
 ** Post-Conditions: returns if player quit or new cave should be created
 *********************************************************/

int Cave::play() {
	set_cave();
	int dead = 0;
	int over = 0;
	while (over <= 0) {
		while (dead == 0) {
			print_cave();
			move();
			dead = room();
			if (dead == -1) {
				gold = true;
				dead = 0;
				rooms.at(adventurer/grid_size).at(adventurer%grid_size).set_event(-1);
			}
			else if (dead == -2) {
				dead = bats();
			}
			dead += check_win();
		}
		over = reset();
		dead = 0;
	}
	return over;
}

/**********************************************************
 ** Function: check win
 ** Description: checks and outputs win conditions
 ** Parameters: none
 ** Pre-Conditions: cave is created
 ** Post-Conditions: return 1 if player won
 *********************************************************/

int Cave::check_win() {
	if (gold == true && adventurer == start) {
		cout << "You escaped with the gold" << endl;
		if (dead_wumpus == true) {
			cout << "and killed the wumpus" << endl;
		}
		return 1;
	}
	return 0;
}

/**********************************************************
 ** Function: move
 ** Description: executes player's move
 ** Parameters: none
 ** Pre-Conditions: grid_size is correct
 ** Post-Conditions: if possible move occured
 *********************************************************/

void Cave::move() {
	string move;
	move = get_move();
	/*Movement cases*/
	if (move == "w" && adventurer / grid_size > 0) {
		adventurer -= grid_size;
	}
	else if (move == "a" && adventurer % grid_size > 0) {
		adventurer -= 1;
	}
	else if (move == "s" && adventurer / grid_size < grid_size - 1) {
		adventurer += grid_size;
	}
	else if (move == "d" && adventurer % grid_size < grid_size - 1) {
		adventurer += 1;
	}
	/*Arrow cases*/
	else if (move == " w" && arrows > 0) {
		arrows--;
		if (wumpus == adventurer - grid_size || wumpus == adventurer - 2 * grid_size || wumpus == adventurer - 3 * grid_size){ 
			kill();
		}
		else {
			wake();
		}
	}
	else if (move == " a" && arrows > 0) {
		arrows--;
		if (wumpus == adventurer - 1 || wumpus == adventurer - 2 || wumpus == adventurer - 3){ 
			kill();
		}
		else {
			wake();
		}
	}
	else if (move == " s" && arrows > 0) {
		arrows--;
		if (wumpus == adventurer + grid_size || wumpus == adventurer + 2 * grid_size || wumpus == adventurer + 3 * grid_size){ 
			kill();
		}
		else {
			wake();
		}
	}
	else if (move == " d" && arrows > 0) {
		arrows--;
		if (wumpus == adventurer + 1 || wumpus == adventurer + 2 || wumpus == adventurer + 3){ 
			kill();
		}
		else {
			cout << "else" << endl;
			wake();
		}
	}
}

/**********************************************************
 ** Function: get move
 ** Description: gets move from user
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: returns move as string
 *********************************************************/

string Cave::get_move() {
	string str;
	cout << "Enter your move: ";
	while(true) {
		getline(cin, str);
		if (str == "w") {
			return "w";
		}
		else if (str == "s"){
			return "s";
		}
		else if (str == "a") {
			return "a";
		}
		else if (str == "d") {
			return "d";
		}
		else if (str == " w") {
			return " w";
		}
		else if (str == " s") {
			return " s";
		}
		else if(str == " a") {
			return " a";
		}
		else if(str == " d") {
			return " d";
		}
		cout << "Enter w,a,s,d: ";
	}
}

/**********************************************************
 ** Function: room
 ** Description: gets room action
 ** Parameters: none
 ** Pre-Conditions: grid size is accurate
 ** Post-Conditions: returns -2, -1, 0, or 1
 *********************************************************/

int Cave::room() {
	int i = adventurer / grid_size;
	int j = adventurer % grid_size;
	return rooms.at(i).at(j).action();
}

/**********************************************************
 ** Function: bats
 ** Description: performs bats action
 ** Parameters: none
 ** Pre-Conditions: adventurer is in bats room
 ** Post-Conditions: adventurer is moved and new room is checked
 *********************************************************/

int Cave::bats() {
	int r = rand() % (grid_size * grid_size);
	adventurer = r;
	/*Performs action for new room*/
	int dead = room();
	if (dead == -1) {
		gold = true;
		rooms.at(adventurer/grid_size).at(adventurer%grid_size).set_event(-1);
	}
	else if (dead == -2) {
		bats();
	}
	return dead;
}

/**********************************************************
 ** Function: wake
 ** Description: wakes the wumpus
 ** Parameters: none
 ** Pre-Conditions: arrow was fired
 ** Post-Conditions: nothing or wumpus was destroyed and new one made
 *********************************************************/

void Cave::wake() {
	int move = rand() % 4;
	cout << move << endl;
	if (move != 0) {
		while(true) {
			move = rand() % (grid_size * grid_size);
			bool none = rooms.at(move/grid_size).at(move%grid_size).check_event();
			if (none == true) {
				rooms.at(wumpus/grid_size).at(wumpus%grid_size).set_event(-1);
				rooms.at(move/grid_size).at(move%grid_size).set_event(4);
				wumpus = move;
				break;
			}
		}
	}
}

/**********************************************************
 ** Function: kill
 ** Description: removes wumpus from game
 ** Parameters: none
 ** Pre-Conditions: adventurer shot wumpus
 ** Post-Conditions: wumpus is removed and dead_wumpus is true
 *********************************************************/

void Cave::kill() {
	cout << "You killed the wumpus" << endl;
	rooms.at(wumpus/grid_size).at(wumpus%grid_size).set_event(-1);
	dead_wumpus = true;
}

/**********************************************************
 ** Function: set cave
 ** Description: puts events in rooms
 ** Parameters: none
 ** Pre-Conditions: cave is created and grid_size is correct
 ** Post-Conditions: cave is set-up for play
 *********************************************************/

void Cave::set_cave() {
	/*Get random numbers*/
	int r1, r2, r3, r4, r5, r6, r7;
	randomize(r1, r2, r3, r4, r5, r6, r7);
	/*Set event pointers*/
	for (int i = 0; i < grid_size; i++) {
		for (int j = 0; j < grid_size; j++) {
			if (i == r1 / grid_size && j == r1 % grid_size) {
				rooms.at(i).at(j).set_event(1);
			}
			else if (i == r2 / grid_size && j == r2 % grid_size) {
				rooms.at(i).at(j).set_event(1);
			}
			else if (i == r3 / grid_size && j == r3 % grid_size) {
				rooms.at(i).at(j).set_event(2);
				gold_begin = r3;
			}
			else if (i == r4 / grid_size && j == r4 % grid_size) {
				rooms.at(i).at(j).set_event(3);
			}
			else if (i == r5 / grid_size && j == r5 % grid_size) {
				rooms.at(i).at(j).set_event(3);
			}
			else if (i == r6 / grid_size && j == r6 % grid_size) {
				rooms.at(i).at(j).set_event(4);
				wumpus = r6;
				wumpus_begin = r6;
			}
			else if (i == r7 / grid_size && j == r7 % grid_size) {
				rooms.at(i).at(j).set_event(0);
				adventurer = r7;
				start = r7;
			}
			else {
				rooms.at(i).at(j).set_event(0);
			}
		}
	}
}

/**********************************************************
 ** Function: reset
 ** Description: resets if user wants
 ** Parameters: none
 ** Pre-Conditions: game is over
 ** Post-Conditions: cave is reset, new cave is created, or exits
 *********************************************************/

int Cave::reset() {
	int choice = reset_choice();
	if (choice == 1) { /*create new cave*/
		return 1;
	}
	else if (choice == 2) { /*Reset board*/
		if (dead_wumpus == false) {
			rooms.at(wumpus/grid_size).at(wumpus%grid_size).set_event(-1);
		}
		if (gold == true) {
			gold = false;
			rooms.at(gold_begin/grid_size).at(gold_begin%grid_size).set_event(2);
		}
		adventurer = start;
		wumpus = wumpus_begin;
		rooms.at(wumpus/grid_size).at(wumpus%grid_size).set_event(4);
		dead_wumpus = false;
		arrows = 3;
		return 0;
	}
	else if (choice == 3) { /*exit program*/
		return 3;
	}
}

/**********************************************************
 ** Function: reset_choice
 ** Description: gets user's choice
 ** Parameters: none
 ** Pre-Conditions: game is over
 ** Post-Conditions: returns 1, 2, or 3
 *********************************************************/

int Cave::reset_choice() {
	string str;
	cout << endl << "Do you want to play again?" << endl;
	cout << "1: again with new board" << endl;
	cout << "2: again with same board" << endl;
	cout << "3: quit" << endl;
	cout << "Enter your choice: ";
	while(true) {
		getline(cin, str);
		if(str == "1") {
			return 1;
		}
		else if (str == "2") {
			return 2;
		}
		else if (str == "3") {
			return 3;
		}
		cout << "Enter 1, 2, or 3: ";
	}
}

/**********************************************************
 ** Function: print cave
 ** Description: outputs cave
 ** Parameters: none
 ** Pre-Conditions: grid size is accurate
 ** Post-Conditions: cave is outputted to console
 *********************************************************/

void Cave::print_cave() {
	char c;
	for (int i = 0; i < grid_size; i++) {
		for (int j = 0; j < grid_size; j++) {
			cout << "+---";
		}
		cout << "+" << endl;
		for (int j = 0; j < grid_size; j++) {
			if (i == adventurer / grid_size && j == adventurer % grid_size) {
				c = '*';
			}
			else if (i == start / grid_size && j == start % grid_size) {
				c = 's';
			}
			else {
				c = rooms.at(i).at(j).get_symbol();
			}
			if (debug == false && c != '*'){ /*toggles debug mode*/
				c = ' ';
			}
			cout << "| " << c << " ";
		}
		cout << "|" << endl;
	}
	for (int j = 0; j < grid_size; j++) {
		cout << "+---";
	}
	cout << "+" << endl;
	cout << "You have " << arrows << " arrow(s) left" << endl;
	print_percepts();
}

/**********************************************************
 ** Function: print percepts
 ** Description: prints percepts of adjacent rooms
 ** Parameters: none
 ** Pre-Conditions: grid size is accurate
 ** Post-Conditions: percepts are outputted to console
 *********************************************************/

void Cave::print_percepts() {
	int i = adventurer / grid_size;
	int j = adventurer % grid_size;
	if (i > 0) { /*north room*/
		rooms.at(i - 1).at(j).percept();
	}
	if (i < grid_size - 1) { /*south room*/
		rooms.at(i + 1).at(j).percept();
	}
	if (j > 0) { /*west room*/
		rooms.at(i).at(j - 1).percept();
	}
	if (j < grid_size - 1) { /**east room*/
		rooms.at(i).at(j + 1).percept();
	}
}

/**********************************************************
 ** Function: randomize
 ** Description: gets 7 unique random numbers
 ** Parameters: 7 int addresses
 ** Pre-Conditions: grid size is correct
 ** Post-Conditions: ints are filled
 *********************************************************/

void Cave::randomize(int& r1, int& r2, int& r3, int& r4, int& r5, int& r6, int& r7) {
	bool bad = true;
	r1 = rand() % (grid_size * grid_size);
	r2 = rand() % (grid_size * grid_size);
	r3 = rand() % (grid_size * grid_size);
	r4 = rand() % (grid_size * grid_size);
	r5 = rand() % (grid_size * grid_size);
	r6 = rand() % (grid_size * grid_size);
	r7 = rand() % (grid_size * grid_size);
	while (bad) {
		if (r1 == r2 || r1 == r3 || r1 == r4 || r1 == r5 || r1 == r6 || r1 == r7) {
			r1 = rand() % (grid_size * grid_size);
		}
		else if (r2 == r3 || r2 == r4 || r2 == r5 || r2 == r6 || r2 == r7) {
			r2 = rand() % (grid_size * grid_size);
		}
		else if (r3 == r4 || r3 == r5 || r3 == r6 || r3 == r7) {
			r3 = rand() % (grid_size * grid_size);
		}
		else if (r4 == r5 || r4 == r6 || r4 ==r7) {
			r4 = rand() % (grid_size * grid_size);
		}
		else if (r5 == r6 || r5 == r7) {
			r5 = rand() % (grid_size * grid_size);
		}
		else if (r6 == r7) {
			r6 = rand() % (grid_size * grid_size);
		}
		else {
			bad = false;
		}
	}
}