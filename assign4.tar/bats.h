#ifndef BATS
#define BATS

#include "./event.h"
#include <iostream>

using namespace std;

class Bats : public Event {
private:

public:
	Bats();
	Bats(Bats& bats);
	void operator=(Bats& bats);

	int action();
	void percept();
};

#endif