#ifndef EVENT
#define EVENT

#include <iostream>
#include <string>

using namespace std;

class Event {
private:
	char symbol;
	string message;
public:
	/*Event();
	Event(Event& event);
	void operator=(Event& event);*/

	char get_symbol();
	void set_symbol(char s);

	string get_message();
	void set_message(string s);

	virtual int action() = 0;
	virtual void percept() = 0;
};

#endif 