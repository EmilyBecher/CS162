#ifndef PIT
#define PIT

#include "./event.h"
#include <iostream>

using namespace std;

class Pit : public Event {
private:

public:
	Pit();
	Pit(Pit& pit);
	void operator=(Pit& pit);

	int action();
	void percept();
};

#endif