#ifndef ROOM
#define ROOM

#include "./event.h"
#include "./bats.h"
#include "./gold.h"
#include "./pit.h"
#include "./wumpus.h"
#include <iostream>

using std::cout;

class Room {
private:
	Event* event;
public:
	Room();
	Room(const Room& room);
	void operator=(Room& room);

	~Room();

	char get_symbol();
	void set_symbol(char s);
	Event* get_event() const;

	void set_event(int);
	int action();
	void percept();
	bool check_event();
};

#endif