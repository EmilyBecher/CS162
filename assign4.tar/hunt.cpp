/**********************************************************
 ** Program: hunt.cpp
 ** Author: Emily Becher
 ** Date: 5/23/2021
 ** Description: plays a game of hunt the wumpus with user
 ** Inputs: 2 cmd line args and gameplay decisions
 ** Outputs: Instructions, board, and results
 *********************************************************/

#include "./cave.h"
#include <iostream>
#include <stdlib.h>
#include <cstring>

using namespace std;

int main(int argc, char* argv[]) {
	srand(time(nullptr));
	bool debug = false;
	int size = 5;
	/* Check command line */
	if (argc == 3) {
		for (int i = 0; i < strlen(argv[1]); i++) {
			if((int)argv[1][i] < 48 || (int) argv[1][i] > 57){
				cout << "created game of default size" << endl;
				break;
			}
			size = stod(argv[1]);
			if (size < 4) {
				size = 4;
				cout << "Minimum board size is 4" << endl;
			}
		}
		if (argv[2][0] == '1' || argv[2][0] == 't') {
			debug = true;
		}
	}
	else {
		cout << "expected two arguments" << endl;
	}

	/* Play game */
	int game = 1;
	while (game == 1) {
		Cave cave(size, debug);
		game = cave.play();
		if (game == 3) {
			break;
		}
	}

	cout << "Thanks for playing!" << endl;

	return 0;
}