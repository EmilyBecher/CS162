#include "./room.h"

/**********************************************************
 ** Function: Room constructor
 ** Description: constructs room
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: room is constructed
 *********************************************************/

Room::Room() {
	event = nullptr;
}

/**********************************************************
 ** Function: room copy constructor
 ** Description: creates copy of room
 ** Parameters: room address
 ** Pre-Conditions: new room is uninitialized
 ** Post-Conditions: new room contains copied contents
 *********************************************************/

Room::Room(const Room& room) {
	this -> event = room.get_event();
}

/**********************************************************
 ** Function: room assignment operator overload
 ** Description: copies room to room
 ** Parameters: room address
 ** Pre-Conditions: room is created
 ** Post-Conditions: room contains copied contents
 *********************************************************/

void Room::operator=(Room& room) {
	if (this != &room) {
		if (event != nullptr) { /*check there is stuff to delete*/
			delete event;
			event = nullptr;
		}
		this -> event = room.get_event();
	}
}

/**********************************************************
 ** Function: room destructor
 ** Description: destroys room
 ** Parameters: none
 ** Pre-Conditions: room exists
 ** Post-Conditions: room is destroyed
 *********************************************************/

Room::~Room() {
	if (event != nullptr) {
		delete event;
		event = nullptr;
	}
}

/**********************************************************
 ** Function: get symbol
 ** Description: returns symbol or ' '
 ** Parameters: none
 ** Pre-Conditions: char is expected
 ** Post-Conditions: returns symbol or ' ' if null
 *********************************************************/

char Room::get_symbol() {
	if (event != nullptr) {
		return event->get_symbol();
	}
	return ' ';
}

/**********************************************************
 ** Function: set symbol
 ** Description: sets symbol
 ** Parameters: char s
 ** Pre-Conditions: event isn't null
 ** Post-Conditions: event::set_symbol is called
 *********************************************************/
/*only used for testing*/
void Room::set_symbol(char s) {
	event->set_symbol(s);
}

/**********************************************************
 ** Function: get_event
 ** Description: return event
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: event is returned
 *********************************************************/

Event* Room::get_event() const {
	return event;
}

/**********************************************************
 ** Function: set event
 ** Description: sets event
 ** Parameters: int e
 ** Pre-Conditions: e corresponds to desired event
 ** Post-Conditions: event points to desired event
 *********************************************************/

void Room::set_event(int e) {
	if (e == 1) {
		event = new Bats;
	}
	else if (e == 2) {
		event = new Gold;
	}
	else if (e == 3) {
		event = new Pit;
	}
	else if (e == 4) {
		event = new Wumpus;
	}
	else if (e == -1) {
		delete event;
		event = nullptr;
	}
}

/**********************************************************
 ** Function: action
 ** Description: calls event action if event isn't null
 ** Parameters: none
 ** Pre-Conditions: adventurer is in room
 ** Post-Conditions: action value is returned
 					 1: dead
 					 0: none
 					 -1: gold
 					 -2:bats
 *********************************************************/

int Room::action() {
	if (event != nullptr) {
		return event->action();
	}
	return 0;
}

/**********************************************************
 ** Function: percept
 ** Description: calls event percept if event isn't null
 ** Parameters: none
 ** Pre-Conditions: adventurer is in adjacent room
 ** Post-Conditions: percept is outputted
 *********************************************************/

void Room::percept() {
	if (event != nullptr) {
		event->percept();
	}
}

/**********************************************************
 ** Function: check event
 ** Description: returns if event points to null
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: returns true if event is null
 *********************************************************/

bool Room::check_event() {
	if (event == nullptr) {
		return true;
	}
	return false;
}