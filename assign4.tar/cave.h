#ifndef CAVE
#define CAVE

#include "./room.h"
#include <iostream>
#include <string>
#include <vector>

using std::cout;
using std::endl;
using std::vector;
using std:: string;

class Cave {
private:
	vector<vector<Room>> rooms;
	int grid_size;
	bool debug;
	int adventurer;
	int start;
	int wumpus;
	int wumpus_begin;
	bool dead_wumpus;
	bool gold;
	int gold_begin;
	int arrows;

public:
	Cave();
	Cave(int size, bool debug);

	int play();
	int check_win();
	void move();
	string get_move();
	int room();
	int bats();
	void wake();
	void kill();
	void set_cave();
	int reset();
	int reset_choice();
	void print_cave();
	void print_percepts();
	void randomize(int&, int&, int&, int&, int&, int&, int&);
};

#endif