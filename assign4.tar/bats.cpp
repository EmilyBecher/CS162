#include "./bats.h"

/**********************************************************
 ** Function: Bat constructor
 ** Description: creates bat object
 ** Parameters: none
 ** Pre-Conditions: event class is included
 ** Post-Conditions: bats object created
 *********************************************************/
Bats::Bats() {
	set_symbol('b');
	set_message("You hear wings flapping");
}

/**********************************************************
 ** Function: Bats copy constructor
 ** Description: creates a copy of a bats object
 ** Parameters: address of bats object
 ** Pre-Conditions: bats object is unitialized
 ** Post-Conditions: bats object is created with copied contents
 *********************************************************/

Bats::Bats(Bats& bats) {
	set_symbol(bats.get_symbol());
	set_message(bats.get_message());
}

/**********************************************************
 ** Function: Bats operator= overload
 ** Description: creates a copy of a bats object
 ** Parameters: address of a bats object
 ** Pre-Conditions: bats object is initialized
 ** Post-Conditions: bats object is filled with copied contents
 *********************************************************/

void Bats::operator=(Bats& bats) {
	set_symbol(bats.get_symbol());
	set_message(bats.get_message());
}

/**********************************************************
 ** Function: action
 ** Description: outputs what happened and returns event value
 ** Parameters: none
 ** Pre-Conditions: player is in the room
 ** Post-Conditions: event is outputted and -2 is returned so
 					 cave knows to move adventurer
 *********************************************************/

int Bats::action() {
	cout << "The bats moved you to a new room" << endl;
	return -2;
}

/**********************************************************
 ** Function: percept
 ** Description: outputs message
 ** Parameters: none
 ** Pre-Conditions: adventurer is in adjacent room
 ** Post-Conditions: message is outputted to console
 *********************************************************/

void Bats::percept() {
	cout << get_message() << endl;
}