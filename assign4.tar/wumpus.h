#ifndef WUMPUS
#define WUMPUS

#include "./event.h"
#include <iostream>

using namespace std;

class Wumpus : public Event {
private:

public:
	Wumpus();
	Wumpus(Wumpus& wumpus);
	void operator=(Wumpus& wumpus);

	int action();
	void percept();
};

#endif