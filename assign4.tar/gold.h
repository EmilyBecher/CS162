#ifndef GOLD
#define GOLD

#include "./event.h"
#include <iostream>

using namespace std;

class Gold : public Event {
private:

public:
	Gold();
	Gold(Gold& gold);
	void operator=(Gold& gold);

	int action();
	void percept();
};

#endif