#include "./event.h"

/*Event::Event() {
	symbol = ' ';
}

Event::Event(Event& event) {
	this -> symbol = event.get_symbol();
}

void Event::operator=(Event& event) {
	this -> symbol = event.get_symbol();
}*/ /*event is abstract*/

/**********************************************************
 ** Function: get_symbol
 ** Description: returns symbol
 ** Parameters: none
 ** Pre-Conditions: symbol exists
 ** Post-Conditions: symbol is returned
 *********************************************************/

char Event::get_symbol() {
	return symbol;
}

/**********************************************************
 ** Function: set symbol
 ** Description: sets symbol
 ** Parameters: char s
 ** Pre-Conditions: symbol exists
 ** Post-Conditions: symbol = s
 *********************************************************/

void Event::set_symbol(char s) {
	this -> symbol = s;
}

/**********************************************************
 ** Function: get message
 ** Description: returns message
 ** Parameters: none
 ** Pre-Conditions: message exists
 ** Post-Conditions: message is returned
 *********************************************************/

string Event::get_message() {
	return message;
}

/**********************************************************
 ** Function: set message
 ** Description: sets message
 ** Parameters: string s
 ** Pre-Conditions: message exists
 ** Post-Conditions: message = s
 *********************************************************/

void Event::set_message(string s) {
	this -> message = s;
}