#include "./gold.h"

/**********************************************************
 ** Function: Gold constructor
 ** Description: constructs gold object
 ** Parameters: none
 ** Pre-Conditions: event class is included
 ** Post-Conditions: gold object is created
 *********************************************************/

Gold::Gold() {
	set_symbol('g');
	set_message("You see a glimmer nearby");
}

/**********************************************************
 ** Function: gold cpoy constructor
 ** Description: copies gold object to new gold object
 ** Parameters: address of gold object
 ** Pre-Conditions: new gold object is uninitialized
 ** Post-Conditions: gold object contains copied contents
 *********************************************************/

Gold::Gold(Gold& gold) {
	set_symbol(gold.get_symbol());
	set_message(gold.get_message());
}

/**********************************************************
 ** Function: gold operator= overload
 ** Description: copies gold into existing gold
 ** Parameters: address of gold
 ** Pre-Conditions: gold is initialized
 ** Post-Conditions: gold contains copied contents
 *********************************************************/

void Gold::operator=(Gold& gold) {
	set_symbol(gold.get_symbol());
	set_message(gold.get_message());
}

/**********************************************************
 ** Function: action
 ** Description: outputs action and returns action value
 ** Parameters: none
 ** Pre-Conditions: adventurer is in the room
 ** Post-Conditions: outputs message and returns -1 so cave
					 knows to move gold from board to player
 *********************************************************/

int Gold::action() {
	cout << "You picked up the gold" << endl;
	return -1;
}

/**********************************************************
 ** Function: percept
 ** Description: outputs message
 ** Parameters: none
 ** Pre-Conditions: adventurer is in adjacent room
 ** Post-Conditions: message is outputted to console
 *********************************************************/

void Gold::percept() {
	cout << get_message() << endl;
}