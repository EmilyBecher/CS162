#include "./pit.h"

/**********************************************************
 ** Function: pit constructor
 ** Description: constructs pit object
 ** Parameters: none
 ** Pre-Conditions: event class is included
 ** Post-Conditions: pit is constructed
 *********************************************************/

Pit::Pit() {
	set_symbol('p');
	set_message("You feel a breeze");
}

/**********************************************************
 ** Function: pit copy constructor
 ** Description: copies pit into new pit
 ** Parameters: pit address
 ** Pre-Conditions: new pit is uninitialized
 ** Post-Conditions: new pit contain copied contents
 *********************************************************/

Pit::Pit(Pit& pit) {
	set_symbol(pit.get_symbol());
	set_message(pit.get_message());
}

/**********************************************************
 ** Function: pit operator= overload
 ** Description: copies pit into pit
 ** Parameters: pit address
 ** Pre-Conditions: pit is initialized
 ** Post-Conditions: pit contains copied contents
 *********************************************************/

void Pit::operator=(Pit& pit) {
	set_symbol(pit.get_symbol());
	set_message(pit.get_message());
}

/**********************************************************
 ** Function: action
 ** Description: outputs action and returns action value
 ** Parameters: none
 ** Pre-Conditions: adventurer is in the room
 ** Post-Conditions: message is outputted and 1 is returned so
 					 cave knows that adventurer died
 *********************************************************/

int Pit::action() {
	cout << "You fell into a bottomless pit" << endl;
	return 1;
}

/**********************************************************
 ** Function: percept
 ** Description: outputs message
 ** Parameters: none
 ** Pre-Conditions: adventurer is in adjacent room
 ** Post-Conditions: percept is outputted
 *********************************************************/

void Pit::percept() {
	cout << get_message() << endl;
}