/*********************************************************
 ** Program Filename: assign1.cpp
 ** Author: Emily Becher
 ** Date: 4-10-2021
 ** Description: sort spellbooks by pages or average spell success rate
 				 or sorts spells by type.
 ** Input: a text file with spellbook information in expected format
 ** Ouput: sorted spellbooks to console or given file
 *********************************************************/

#include "a1_functions.h"
#include <iostream>
#include <fstream>

using std::cout;
using std::endl;
using std::ios;

int main(int argc, char* argv[]) {
	/* Check for valid command line arguments */
	if(argc != 2) {		/*Two arguments weren't inputted */
		cout << "Expected two arguments." << endl;
		return 1;
	}
	bool quit = check_cmd_line(argv[1]);
	if (quit) {
		return 1;
	}

	/* Open File */
	ifstream ifile(argv[1], ios::in);
	if(ifile.fail()) {
		cout << "Error opening file." << endl;
		return 1;
	}

	/* Read Data From File */
	int n;
	ifile >> n;
	spellbook* books = create_spellbooks(n);
	get_spellbook_data(books, n, ifile);
	ifile.close();		/* Close File */

	/* All user interaction */
	while(!quit) {
		int op = get_op();
		switch (op) {
			case 1:
				page_sort(books, n);
				break;
			case 2:
				type_sort(books, n);
				break;
			case 3:
				success_sort(books, n);
				break;
			default:
				quit = 1;
		}
	}

	/* Free memory */
	delete_spellbook_data(books, n);

	return 0;
}