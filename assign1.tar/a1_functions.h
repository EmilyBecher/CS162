#ifndef SPELL
#define SPELL

#include <string>
#include <fstream>

using std::string;
using std::ifstream;

struct spellbook {
	string title;
	string author;
	int num_pages;
	int edition;
	int num_spells;
	float avg_success_rate;
	struct spell *s;
};

struct spell {
	string name;
	float success_rate;
	string effect;
};

/*Required Functions*/
spellbook* create_spellbooks(int);
void get_spellbook_data(spellbook*, int, ifstream &);
spell* create_spells(int);
void get_spell_data(spell*, int, ifstream &);
void delete_spellbook_data(spellbook*, int);

bool check_cmd_line(char*);
int get_op();
void get_int(int &, int, int);
void page_sort(spellbook*, int);
void type_sort(spellbook*, int);
void success_sort(spellbook*, int);
string output_type();
void output_page(spellbook*, string, int, int);
void output_rate(spellbook*, string, int, int);
void output_spell(spellbook*, int, string, string);
void average(spellbook*, int);
void end_section(string);

#endif