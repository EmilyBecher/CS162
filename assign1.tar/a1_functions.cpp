#include "a1_functions.h"
#include <string>
#include <fstream>
#include <iostream>
#include <cstring>

using std::string;
using std::ifstream;
using std::ofstream;
using std::cout;
using std::cin;
using std::endl;
using std::ios;

/*********************************************************
 ** Function: create_spellbooks
 ** Description: creates a dynamic array of spellbooks
 ** Parameters: int n
 ** Pre-Conditions: n is the number of spellbooks
 ** Post-Conditions: dynamic memory is allocated
 *********************************************************/

spellbook* create_spellbooks(int n) {
	spellbook *books = new spellbook[n];
	return books;
}

/*********************************************************
 ** Function: get_spellbook_data
 ** Description: reads in information from file
 ** Parameters: spellbook* books, int n, ifstream & ifile
 ** Pre-Conditions: file is open and the proper format
 ** Post-Conditions: spellbook array and spell array are filled
 *********************************************************/

void get_spellbook_data(spellbook* books, int n, ifstream & ifile) {
	for(int i = 0; i < n; i++) {
		ifile >> books[i].title;
		ifile >> books[i].author;
		ifile >> books[i].num_pages;
		ifile >> books[i].edition;
		ifile >> books[i].num_spells;
		books[i].s = create_spells(books[i].num_spells);
		get_spell_data(books[i].s, books[i].num_spells, ifile);
	}
	average(books, n);
}

/*********************************************************
 ** Function: create_spells
 ** Description: create dynamic spell array
 ** Parameters: int n
 ** Pre-Conditions: n is the number of spells
 ** Post-Conditions: dynamic memory is allocated
 *********************************************************/

spell* create_spells(int n) {
	spell *spells = new spell[n];
	return spells;
}

/*********************************************************
 ** Function: get_spell_data
 ** Description: reads spell information from file
 ** Parameters: spell* spells, int n, ifstream & ifile
 ** Pre-Conditions: file is open and properly formatted 
 ** Post-Conditions: spell array is filled
 *********************************************************/

void get_spell_data(spell* spells, int n, ifstream & ifile) {
	for(int i = 0; i < n; i++) {
		ifile >> spells[i].name;
		ifile >> spells[i].success_rate;
		ifile >> spells[i].effect;
	}
}

/*********************************************************
 ** Function: delete_spellbook_data
 ** Description: frees all dynamic memory and sets points to NULL
 ** Parameters: spellbook* books, int n
 ** Pre-Conditions: n is the number of spellbooks
 ** Post-Conditions: all dynamic memory is freed
 *********************************************************/

void delete_spellbook_data(spellbook* books, int n) {
	for(int i = 0; i < n; i++) {
		delete [] books[i].s;
		books[i].s = NULL;
	}
	delete [] books;
	books = NULL;
}

/*********************************************************
 ** Function: check_cmd_line
 ** Description: returns 0 if a .txt file was inputted
 ** Parameters: int c, char* v
 ** Pre-Conditions: 
 ** Post-Conditions: returns 1 if cmd line arguments were wrong
 *********************************************************/

bool check_cmd_line(char* v) {
	int n = strlen(v) - 1;
	/* Checks for .txt extension */
	if(v[n] != 't' || v[n - 1] != 'x' || v[n - 2] != 't' || v[n - 3] != '.') {
		cout << "Expected .txt file" << endl;
		return 1;
	}
	return 0;
}

/*********************************************************
 ** Function: get_op
 ** Description: gets the operation the user wants to perform
 ** Parameters: 
 ** Pre-Conditions: int is expected in main
 ** Post-Conditions: Returns operation as int
 *********************************************************/

int get_op() {
	cout << "What would you like to do?" << endl;
	cout << "Press 1 to sort spellbooks by number of pages." << endl;
	cout << "Press 2 to sort spells by their effect." << endl;
	cout << "Press 3 to sort spellbooks by average success rate." << endl;
	cout << "Press 4 to quit" << endl;
	int op;
	get_int(op, 1, 4);
	return op;
}

/*********************************************************
 ** Function: get_int
 ** Description: reprompts user until int between given min and max is entered
 ** Parameters: int &num, int min, int max
 ** Pre-Conditions: max is larger than min
 ** Post-Conditions: num is an integer between min and max
 *********************************************************/

void get_int(int &num, int min, int max) {
	bool bad = 1;
	string str;
	while(bad) {
		cout << "Your selection: ";
		getline(cin, str);
		for(int i = 0; i < str.length(); i++) {
			/* Checks for invalid characters */
			if((int)str[i] < 48 || (int)str[i] > 57) {
				cout << "Invalid input." << endl;
				break;
			}
			/* Checks that number is in range */
			else if(i == str.length() - 1) {
				num = stod(str);
				if(num > max || num < min) {
					cout << "Enter a number between " << min << " and " 
						 << max << "." << endl;
					break;
				}
				/* Valid input*/
				else {
					bad = 0;
					break;
				}
			}
		}
	}
}

/*********************************************************
 ** Function: page_sort
 ** Description: outputs spellbooks by ascending page count
 ** Parameters: spellbook* books, int n
 ** Pre-Conditions: n is the number of spellbooks
 ** Post-Conditions: ordered spellbooks are outputted
 *********************************************************/

void page_sort(spellbook* books, int n) {
	string str;
	str = output_type();		/* Gets output method from user */
	int print = 0;
	int temp = -1;
	if (str == "1") {		/* 1 means to output to screen */
		cout << endl;
		cout << "Spellbooks by Page Number:" << endl;
	}
	while(print < n) {
		int min = 999999999;
		for(int i = 0; i < n; i++) {
			if(books[i].num_pages > temp && books[i].num_pages < min) {
				min = books[i].num_pages;
			}
		}
		temp = min;
		for (int i = 0; i < n; i++) {
			if(books[i].num_pages == min) {
				output_page(books, str, i, print);
				print++;
			}
		}
	}
	end_section(str);
}

/*********************************************************
 ** Function: type_sort
 ** Description: outputs spells by effect
 ** Parameters: spellbook* books, int n
 ** Pre-Conditions: n is the number of spellbooks
 ** Post-Conditions: ordered spells are outputted
 *********************************************************/

void type_sort(spellbook* books, int n) {
	string str;
	str = output_type();		/* Gets output method from user */
	if (str == "1") {
		cout << endl;
		cout << "Spells by Type:" << endl;
	}
	else {
		ofstream ofile(str, ios::app);
		ofile << "Spells by Type:" << endl;
		ofile.close();
	}
	output_spell(books, n, str, "bubble");
	output_spell(books, n, str, "memory_loss");
	output_spell(books, n, str, "fire");
	output_spell(books, n, str, "poison");
	output_spell(books, n, str, "death");
	end_section(str);
}

/*********************************************************
 ** Function: success_sort
 ** Description: outputs spellbooks by descending success rate
 ** Parameters: spellbook* books, int n
 ** Pre-Conditions: n is the number of spellbooks
 ** Post-Conditions: ordered spellbooks are outputted
 *********************************************************/

void success_sort(spellbook* books, int n) {
	string str;
	str = output_type();		/* Gets output method from user */
	int print = 0;
	float temp = 101.00;
	if (str == "1") {
		cout << endl;
		cout << "Spellbooks by Average Success Rate:" << endl;
	}
	while(print < n) {
		float max = 0.00;
		for(int i = 0; i < n; i++) {
			if(books[i].avg_success_rate > max && books[i].avg_success_rate < temp) {
				max = books[i].avg_success_rate;
			}
		}
		temp = max;
		for (int i = 0; i < n; i++) {
			if(books[i].avg_success_rate == max) {
				output_rate(books, str, i, print);
				print++;
			}
		}
	}
	end_section(str);
}

/*********************************************************
 ** Function: output_type
 ** Description: gets the user's preferred output method
 ** Parameters:
 ** Pre-Conditions: string is expected as return type
 ** Post-Conditions: filename or 1 is returned
 *********************************************************/

string output_type() {
	string file;
	cout << endl << "How would you like the information outputted?" << endl;
	cout << "Press 1 to output to screen" << endl;
	cout << "Press 2 to output to a text file" << endl;
	int op;
	get_int(op, 1, 2);

	if (op == 1) {
		file = "1";
	}
	else {
		bool bad = 1;
		while(bad) {
			cout << "Enter filename: ";
			getline(cin, file);
			int n = file.size() - 1;
			if(file[n] == 't' && file[n - 1] == 'x' 
				&& file[n - 2] == 't' && file[n - 3] == '.') {
				bad = 0;
			}
			else {
				cout << "Expected .txt file" << endl;
			}
		}
	}
	return file;
}

/*********************************************************
 ** Function: output_page
 ** Description: writes a spellbook to screen or file
 ** Parameters: spellbook* book, string filename, int index, int count
 ** Pre-Conditions: index is the index of the next highest page count
 ** Post-Conditions: spellbook is outputted to screen or file
 *********************************************************/

void output_page(spellbook* books, string filename, int index, int count) {
	if (filename == "1") {
		cout << books[index].title << " ";
		cout << books[index].num_pages << endl;
	}
	else {
		ofstream ofile(filename, ios::app);
		if (count == 0) {
			ofile << "Spellbooks by Page Number" << endl;
		}
		ofile << books[index].title << " ";
		ofile << books[index].num_pages << endl;
		ofile.close();
	}
}

/*********************************************************
 ** Function: output_rate
 ** Description: write spellbook to screen or file
 ** Parameters: spellbook* books, string filename, int index, int count
 ** Pre-Conditions: index is the index of next lowest success rate
 ** Post-Conditions: spellbook is outputted to screen or file
 *********************************************************/

void output_rate(spellbook* books, string filename, int index, int count) {
	if (filename == "1") {
		cout << books[index].title << " ";
		cout << books[index].avg_success_rate << endl;
	}
	else {
		ofstream ofile(filename, ios::app);
		if (count == 0) {
			ofile << "Spellbooks by Average Success Rate" << endl;
		}
		ofile << books[index].title << " ";
		ofile << books[index].avg_success_rate << endl;
		ofile.close();
	}
}

/*********************************************************
 ** Function: output_spell
 ** Description: writes spells of given type to screen or file
 ** Parameters: spellbook* books, int n, string filename, string type
 ** Pre-Conditions: type is given in the correct order
 ** Post-Conditions: all spells of the effect type are outputted
 *********************************************************/

void output_spell(spellbook* books, int n, string filename, string type) {
	for (int i = 0; i < n; i++)	{
		for (int j = 0; j < books[i].num_spells; j++) {
			if (books[i].s[j].effect == type) {
				if (filename == "1") {
					cout << books[i].s[j].effect << " ";
					cout << books[i].s[j].name << endl;
				}
				else {
					ofstream ofile(filename, ios::app);
					ofile << books[i].s[j].effect << " ";
					ofile << books[i].s[j].name << endl;
				}
			}
		}
	}
}

/*********************************************************
 ** Function: average
 ** Description: calculates the average success rate an assigns it
 ** Parameters: spellbook* books, int n
 ** Pre-Conditions: n is the number of spellbooks
 ** Post-Conditions: spellbooks average success rate is filled
 *********************************************************/

void average(spellbook* books, int n) {
	for(int i = 0; i < n; i++) {
		float sum = 0;
		for(int j = 0; j < books[i].num_spells; j++) {
			sum += books[i].s[j].success_rate;
		}
		books[i].avg_success_rate = sum / books[i].num_spells;
	}
}

/*********************************************************
 ** Function: end_section
 ** Description: adds a spacer line and if file prints that information was appended
 ** Parameters: string filename
 ** Pre-Conditions: information was just appended to file
 ** Post-Conditions: outputs look nice
 *********************************************************/

void end_section(string filename) {
	if (filename == "1") {
		cout << endl;
	}
	else {
		ofstream ofile(filename, ios::app);
		ofile << endl;
		ofile.close();
		cout << "Appended information to provided file." << endl << endl;
	}
}