#include "./sea_lion.h"

#include <stdlib.h>

/**********************************************************
 ** Function: sea lion constructor
 ** Description: constructs baby sea lion
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: sea lion is constructed
 *********************************************************/

Sea_lion::Sea_lion() {
	set_age(0);
	set_cost(800);
	set_baby_rate(1);
	set_food_mult(1);
	set_rev_mult(0.2);
}

/**********************************************************
 ** Function: parameterized constructor
 ** Description: constructs sea lion of given age
 ** Parameters: age
 ** Pre-Conditions: none
 ** Post-Conditions: sea lion is created
 *********************************************************/

Sea_lion::Sea_lion(int age) {
	set_age(age);
	set_cost(800);
	set_baby_rate(1);
	set_food_mult(1);
	set_rev_mult(0.2);
}

/**********************************************************
 ** Function: copy constructor
 ** Description: copies sea lion into new sea lion
 ** Parameters: sea lion address
 ** Pre-Conditions: sea lion has no contents
 ** Post-Conditions: sea lion is created
 *********************************************************/

Sea_lion::Sea_lion(const Sea_lion& seal) {
	set_age(seal.get_age());
	set_cost(seal.get_cost());
	set_baby_rate(seal.get_baby_rate());
	set_food_mult(seal.get_food_mult());
	set_rev_mult(seal.get_rev_mult());
}

/**********************************************************
 ** Function: sea lion destructor
 ** Description: destroys sea lion
 ** Parameters: none
 ** Pre-Conditions: sea lion exists
 ** Post-Conditions: sea lion no longer exists
 *********************************************************/

Sea_lion::~Sea_lion() {

}

/**********************************************************
 ** Function: boom
 ** Description: returns random amount betwee 150-400
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: extra revenue is returned
 *********************************************************/

float Sea_lion::boom() {
	float amount = rand() % 251 + 150;
	if (get_age() < 6) { /*double revenue for babies*/
		return amount * 2;
	}
	return amount;
}