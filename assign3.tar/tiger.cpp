#include "./tiger.h"

/**********************************************************
 ** Function: default constructor
 ** Description: creates baby tiger
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: tiger is created
 *********************************************************/

Tiger::Tiger() {
	set_age(0);
	set_cost(10000);
	set_baby_rate(3);
	set_food_mult(5);
	set_rev_mult(0.1);
}

/**********************************************************
 ** Function: parameterized constructor
 ** Description: constructs tiger of given age
 ** Parameters: age
 ** Pre-Conditions: none
 ** Post-Conditions: tiger is created
 *********************************************************/

Tiger::Tiger(int age) {
	set_age(age);
	set_cost(10000);
	set_baby_rate(3);
	set_food_mult(5);
	set_rev_mult(0.1);
}

/**********************************************************
 ** Function: copy constructor
 ** Description: copies contents of tiger
 ** Parameters: tiger address
 ** Pre-Conditions: constructed tiger doesn't have contents
 ** Post-Conditions: tiger is constructed
 *********************************************************/

Tiger::Tiger(const Tiger& tiger) {
	set_age(tiger.get_age());
	set_cost(tiger.get_cost());
	set_baby_rate(tiger.get_baby_rate());
	set_food_mult(tiger.get_food_mult());
	set_rev_mult(tiger.get_rev_mult());
}

/**********************************************************
 ** Function: tiger destructor
 ** Description: destroys tiger
 ** Parameters: none
 ** Pre-Conditions: tiger exists
 ** Post-Conditions: tiger no longer exists
 *********************************************************/

Tiger::~Tiger() {
	
}