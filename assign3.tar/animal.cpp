#include "./animal.h"
#include <iostream>

using namespace std;

/**********************************************************
 ** Function: Animal constructor
 ** Description: creates a generic animal
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: animal is created
 *********************************************************/

Animal::Animal() {
	age = 0;
	cost = 0;
	baby_rate = 0;
	food_mult = 0;
	rev_mult = 0;
}

/**********************************************************
 ** Function: animal destructor
 ** Description: destroys animal
 ** Parameters: none
 ** Pre-Conditions: animal exists
 ** Post-Conditions: animal no longer exists
 *********************************************************/

Animal::~Animal() {

}

/**********************************************************
 ** Function: get age
 ** Description: returns animal's age
 ** Parameters: none
 ** Pre-Conditions: animal has age
 ** Post-Conditions: age is returned
 *********************************************************/

int Animal::get_age() const{
	return age;
}

/**********************************************************
 ** Function: get cost
 ** Description: returns cost of animal
 ** Parameters: none
 ** Pre-Conditions: animal has cost
 ** Post-Conditions: cost is returned
 *********************************************************/

int Animal::get_cost() const{
	return cost;
}

/**********************************************************
 ** Function: get baby rate
 ** Description: returns the number of babies per birth
 ** Parameters: none
 ** Pre-Conditions: animal has baby_rate
 ** Post-Conditions: returns baby_rate
 *********************************************************/

int Animal::get_baby_rate() const{
	return baby_rate;
}

/**********************************************************
 ** Function: get food mult
 ** Description: returns the animal's food multiplier
 ** Parameters: none
 ** Pre-Conditions: animal has food_mult
 ** Post-Conditions: returns food_mult
 *********************************************************/

int Animal::get_food_mult() const{
	return food_mult;
}

/**********************************************************
 ** Function: get_rev_mult
 ** Description: returns animal's revenue multiplier
 ** Parameters: none
 ** Pre-Conditions: animal has rev_mult
 ** Post-Conditions: returns rev_mult
 *********************************************************/

float Animal::get_rev_mult() const{
	return rev_mult;
}

/**********************************************************
 ** Function: set_age
 ** Description: mutates age
 ** Parameters: age
 ** Pre-Conditions: age is int
 ** Post-Conditions: age is changed
 *********************************************************/

void Animal::set_age(int age) {
	this -> age = age;
}

/**********************************************************
 ** Function: set cost
 ** Description: mutates cost
 ** Parameters: cost
 ** Pre-Conditions: cost is int
 ** Post-Conditions: cost is changed
 *********************************************************/

void Animal::set_cost(int cost) {
	this -> cost = cost;
}

/**********************************************************
 ** Function: set baby rate
 ** Description: mutates baby rate
 ** Parameters: rate
 ** Pre-Conditions: rate is int
 ** Post-Conditions: baby_rate is changed
 *********************************************************/

void Animal::set_baby_rate(int rate) {
	this -> baby_rate = rate;
}

/**********************************************************
 ** Function: set_food_mult
 ** Description: mutates food_mult
 ** Parameters: mult
 ** Pre-Conditions: mult is int
 ** Post-Conditions: food_mult is changed
 *********************************************************/

void Animal::set_food_mult(int mult) {
	this -> food_mult = mult;
}

/**********************************************************
 ** Function: set rev mult
 ** Description: mutates rev_mult
 ** Parameters: mult
 ** Pre-Conditions: mult is float
 ** Post-Conditions: rev_mult is changed
 *********************************************************/

void Animal::set_rev_mult(float mult) {
	this -> rev_mult = mult;
}

/**********************************************************
 ** Function: print animal
 ** Description: outputs animal age in months
 ** Parameters: none
 ** Pre-Conditions: animal has age
 ** Post-Conditions: age is outputted to screen
 *********************************************************/

void Animal::print_animal() {
	cout << "Age: " << age << " months" << endl;
}

/**********************************************************
 ** Function: revenue
 ** Description: calculates the revenue for the animal
 ** Parameters: none
 ** Pre-Conditions: animal is initialized
 ** Post-Conditions: animal revenue is returned
 *********************************************************/

float Animal::revenue() {
	float amount = cost * rev_mult;
	if (age < 6) {
		return amount * 2;
	}
	return amount;
}

/**********************************************************
 ** Function: sick_cost
 ** Description: returns the cost of healing the animal
 ** Parameters: none
 ** Pre-Conditions: animal is initialized
 ** Post-Conditions: cost of treatment is outputted
 *********************************************************/

float Animal::sick_cost() {
	if (age < 6) {
		return cost;
	}
	return cost / 2;
}