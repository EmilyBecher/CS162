/**********************************************************
** Program: Zoo Tycoon
** Author: Emily Becher
** Date: 05/08/2021
** Description: Plays a game of zoo tycoon for 24 months
** Inputs: boolean and integer inputs from user
** Outputs: instructions to the screen
***********************************************************/

#include "./animal.h"
#include "./bear.h"
#include "./sea_lion.h"
#include "./tiger.h"
#include "./zoo.h"

#include <iostream>
#include <stdlib.h>

using namespace std;

int main() {
	/*seed random number*/
	srand(time(nullptr));
	cout << "Welcome to Zoo Tycoon!" << endl;

	/*construct zoo*/
	Zoo z;

	/*play game*/
	while(z.get_bank() >= 0) {
		z.next_month();
		if (z.get_month() == 24) { /*End of game*/
			cout << "Congrats you made it two years." << endl;
			cout << "You ended with $" << z.get_bank() << "." << endl;
			break;
		}
	}

	cout << endl << "You ran the zoo for " << z.get_month() << " months." << endl;
}