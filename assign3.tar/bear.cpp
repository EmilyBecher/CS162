#include "./bear.h"

/**********************************************************
 ** Function: bear constructor
 ** Description: creates a baby bear
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: creates bear
 *********************************************************/

Bear::Bear() {
	set_age(0);
	set_cost(5000);
	set_baby_rate(2);
	set_food_mult(3);
	set_rev_mult(0.1);
}

/**********************************************************
 ** Function: parameterized constructor
 ** Description: creates bear of given age
 ** Parameters: age
 ** Pre-Conditions: none
 ** Post-Conditions: bear is created
 *********************************************************/

Bear::Bear(int age) {
	set_age(age);
	set_cost(5000);
	set_baby_rate(2);
	set_food_mult(3);
	set_rev_mult(0.1);
}

/**********************************************************
 ** Function: copy constructor
 ** Description: copies bear to new bear
 ** Parameters: bear address
 ** Pre-Conditions: created bear is empty
 ** Post-Conditions: bear is created
 *********************************************************/

Bear::Bear(const Bear& bear) {
	set_age(bear.get_age());
	set_cost(bear.get_cost());
	set_baby_rate(bear.get_baby_rate());
	set_food_mult(bear.get_food_mult());
	set_rev_mult(bear.get_rev_mult());
}

/**********************************************************
 ** Function: bear destructor
 ** Description: destroys bear
 ** Parameters: none
 ** Pre-Conditions: bear exists
 ** Post-Conditions: bear no longer exists
 *********************************************************/

Bear::~Bear() {
	
}