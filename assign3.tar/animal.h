#ifndef ANIMAL
#define ANIMAL

class Animal {
private:
	int age; //baby < 6 mo, adult > 4 yrs
	int cost;
	int baby_rate;
	int food_mult;
	float rev_mult;

public:
	//Construct/Destruct
	Animal();
	~Animal();

	//Accessors
	int get_age() const;
	int get_cost() const;
	int get_baby_rate() const;
	int get_food_mult() const;
	float get_rev_mult() const;

	//Mutators
	void set_age(int);
	void set_cost(int);
	void set_baby_rate(int);
	void set_food_mult(int);
	void set_rev_mult(float);

	//Others
	void print_animal();
	float revenue();
	float sick_cost();
};

#endif