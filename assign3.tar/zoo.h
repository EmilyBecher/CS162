#ifndef ZOO
#define ZOO

#include "animal.h"
#include "sea_lion.h"
#include "bear.h"
#include "tiger.h"

#include <string>

using namespace std;

class Zoo {
private:
	float bank;
	Sea_lion* seals;
	int num_seal;
	Bear* bears;
	int num_bear;
	Tiger* tigers;
	int num_tiger;
	int month;
	float base_food;
	int prob1;
	int prob2;

public:
	/*constructor/destructor*/
	Zoo();
	~Zoo();

	/*accessors*/
	float get_bank();
	int get_month();

	/*mutators*/
	void set_bank(float);

	/*add and remove array elements*/
	void add_seal(int);
	void kill_seal(int);
	void add_bear(int);
	void kill_bear(int);
	void add_tiger(int);
	void kill_tiger(int);

	/*others*/
	void next_month();
	void increment();
	void sick();
	void boom();
	void birth();
	void revenue();
	void purchase();
	void buy_food();
	bool save_animal(float);
	int count_seals();
	int count_bears();
	int count_tigers();
	void print_store();
	bool get_bool(string);
	void choose_animal(int);
	void print_zoo();
	int get_choice(float);
};

#endif