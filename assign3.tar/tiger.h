#ifndef TIGER
#define TIGER

#include "./animal.h"

class Tiger : public Animal {
private:

public:
	//Construt/Destruct
	Tiger();
	Tiger(int);

	Tiger(const Tiger& tiger);

	~Tiger();
	
};

#endif