#ifndef BEAR
#define BEAR

#include "./animal.h"

class Bear : public Animal {
private:


public:
	//Construct/Destruct
	Bear();
	Bear(int);

	Bear(const Bear& bear);

	~Bear();

};

#endif