#ifndef LION
#define LION

#include "./animal.h"
#include <iostream>

using namespace std;

class Sea_lion : public Animal {
private:
	

public:
	//Construct/Destruct
	Sea_lion();
	Sea_lion(int);

	Sea_lion(const Sea_lion& seal);

	~Sea_lion();

	//others
	float boom();
};

#endif