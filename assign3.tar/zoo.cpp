#include "zoo.h"

#include <stdlib.h>
#include <string>

using namespace std;

/**********************************************************
 ** Function: default constructor
 ** Description: creates zoo with starting conditions
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: a zoo exists
 *********************************************************/

Zoo::Zoo() {
	bank = 100000;
	month = 0;
	base_food = 80;
	num_seal = 0;
	num_tiger = 0;
	num_bear = 0;
	prob1 = 2;
	prob2 = 2;
}

/**********************************************************
 ** Function: zoo destructors
 ** Description: destroys zoo and deletes dynamic arrays
 ** Parameters: none
 ** Pre-Conditions: each array has dynamic memory
 ** Post-Conditions: zoo no longer exists, dynamic memory is freed
 *********************************************************/

Zoo::~Zoo() {
	if (num_seal > 0) { //checks there are seals to be deleted
		delete [] seals;
	}
	if (num_bear > 0) {
		delete [] bears;
	}
	if (num_tiger > 0) {
		delete [] tigers;
	}
	seals = nullptr;
	bears = nullptr;
	tigers = nullptr;
}

/**********************************************************
 ** Function: get_bank
 ** Description: returns bank
 ** Parameters: none
 ** Pre-Conditions: bank exists
 ** Post-Conditions: float is returned
 *********************************************************/

float Zoo::get_bank() {
	return bank;
}

/**********************************************************
 ** Function: get_month
 ** Description: returns month
 ** Parameters: none
 ** Pre-Conditions: month exists
 ** Post-Conditions: returns int
 *********************************************************/

int Zoo::get_month() {
	return month;
}

/**********************************************************
 ** Function: set_bank
 ** Description: mutates bank
 ** Parameters: float
 ** Pre-Conditions: bank exists and is float
 ** Post-Conditions: banks value is changed
 *********************************************************/

void Zoo::set_bank(float bank) {
	this -> bank = bank;
}

/**********************************************************
 ** Function: add_seal
 ** Description: adds seal of given age to seal array
 ** Parameters: int
 ** Pre-Conditions: num_seal is accurate
 ** Post-Conditions: seals is a larger array
 *********************************************************/

void Zoo::add_seal(int age) {
	num_seal++;
	Sea_lion* temp = new Sea_lion[num_seal];
	for (int i = 0; i < num_seal - 1; i++) { /*copies existing seals*/
		temp[i] = seals[i];
	}
	Sea_lion seal(age); //creates new seal
	temp[num_seal - 1] = seal; //copies new seal to last element
	if (num_seal > 1) {
		delete [] seals; //deletes old array
	}
	seals = temp; //sets pointer to new array
	temp = nullptr;
}

/**********************************************************
 ** Function: kill_seal
 ** Description: removes seal from array
 ** Parameters: int
 ** Pre-Conditions: array has at least one element
 ** Post-Conditions: seals array is smaller
 *********************************************************/

void Zoo::kill_seal(int index) {
	num_seal--;
	Sea_lion* temp = new Sea_lion[num_seal];
	int j = 0;
	for (int i = 0; i < num_seal + 1; i++) { /*go through old array*/
		if (i != index) { /*doesn't copy the removed element*/
			temp[j] = seals[i];
			j++;
		}
	}
	delete [] seals;
	seals = temp;
	temp = nullptr;
}

/**********************************************************
 ** Function: add bear
 ** Description: add bear of given age to array
 ** Parameters: int
 ** Pre-Conditions: num_bear is accurate
 ** Post-Conditions: bears is larger
 *********************************************************/

void Zoo::add_bear(int age) {
	num_bear++;
	Bear* temp = new Bear[num_bear];
	for (int i = 0; i < num_bear - 1; i++) {
		temp[i] = bears[i];
	}
	Bear bear(age);
	temp[num_bear - 1] = bear;
	if (num_bear > 1) {
		delete [] bears;
	}
	bears = temp;
	temp = nullptr;
}

/**********************************************************
 ** Function: kill bear
 ** Description: remove specific bear from array
 ** Parameters: int 
 ** Pre-Conditions: bears has elements and num_bear is accurate
 ** Post-Conditions: bears is smaller
 *********************************************************/

void Zoo::kill_bear(int index) {
	num_bear--;
	Bear* temp = new Bear[num_bear];
	int j = 0;
	for (int i = 0; i < num_bear + 1; i++) {
		if (i != index) {
			temp[j] = bears[i];
			j++;
		}
	}
	delete [] bears;
	bears = temp;
	temp = nullptr;
}

/**********************************************************
 ** Function: add tiger
 ** Description: adds tiger of given age to array
 ** Parameters: int
 ** Pre-Conditions: num_tiger is accurate
 ** Post-Conditions: tigers is larger
 *********************************************************/

void Zoo::add_tiger(int age) {
	num_tiger++;
	Tiger* temp = new Tiger[num_tiger];
	for (int i = 0; i < num_tiger - 1; i++) {
		temp[i] = tigers[i];
	}
	Tiger tiger(age);
	temp[num_tiger - 1] = tiger;
	if (num_tiger > 1) {
		delete [] tigers;
	}
	tigers = temp;
	temp = nullptr;
}

/**********************************************************
 ** Function: kill tiger
 ** Description: removes specific tiger from array
 ** Parameters: int
 ** Pre-Conditions: tigers has elements and num_tiger is accurate
 ** Post-Conditions: tigers is smaller
 *********************************************************/

void Zoo::kill_tiger(int index) {
	num_tiger--;
	Tiger* temp = new Tiger[num_tiger];
	int j = 0;
	for (int i = 0; i < num_tiger + 1; i++) {
		if (i != index) {
			temp[j] = tigers[i];
			j++;
		}
	}
	delete [] tigers;
	tigers = temp;
	temp = nullptr;
}

/**********************************************************
 ** Function: next_month
 ** Description: goes through one month of game play
 ** Parameters: none
 ** Pre-Conditions: things are set-up
 ** Post-Conditions: one month is executed
 *********************************************************/

void Zoo::next_month() {
	increment(); 
	print_zoo();
	/*gets random event*/
	int num = rand() % 8;
	if ((num/prob1) == 1) {
		sick();
	}
	else if ((num/prob2) == 2) {
		boom();
	}
	else if ((num/prob2) == 3) {
		birth();
	}
	if (month > 1) { /*Doesn't get revenue for first month*/
		revenue();
	}
	purchase();
	buy_food();
}

/**********************************************************
 ** Function: increment
 ** Description: increases all ages and month number
 ** Parameters: none
 ** Pre-Conditions: num_animal vars are accurate
 ** Post-Conditions: all timed variables are incremented
 *********************************************************/

void Zoo::increment() {
	cout << endl << "Month " << ++month << endl;
	for (int i = 0; i < num_seal; i++) {
		seals[i].set_age(seals[i].get_age() + 1);
	}
	for (int i = 0; i < num_tiger; i++) {
		tigers[i].set_age(tigers[i].get_age() + 1);
	}
	for (int i = 0; i < num_bear; i++) {
		bears[i].set_age(bears[i].get_age() + 1);
	}
}

/**********************************************************
 ** Function: sick
 ** Description: randomly selects animal and either heals or kills them
 ** Parameters: none
 ** Pre-Conditions: animal counters are accurate
 ** Post-Conditions: nothing, cost subtracted, or animal killed
 *********************************************************/

void Zoo::sick() {
	bool saved;
	if (num_seal > 0 || num_bear > 0 || num_tiger > 0) { /*checks for animals*/
		int num = rand() % (num_seal + num_bear + num_tiger);
		if (num + 1 <= num_seal) { /*sick animal is seal*/
			cout << "Seal " << num + 1 << " is sick" << endl;
			saved = save_animal(seals[num].sick_cost());
			if (saved == 1) {
				bank -= seals[num].sick_cost();
			}
			else {
				kill_seal(num);
			}
			num = -1; /*ensures following ifs won't be entered*/
		}
		num -= num_seal;
		if (num + 1 <= num_bear && num >= 0) { /*sick animal is bear*/
			cout << "Bear " << num + 1 << " is sick" << endl;
			saved = save_animal(bears[num].sick_cost());
			if (saved == 1) {
				bank -= bears[num].sick_cost();
			}
			else {
				kill_bear(num);
			}
			num = -1;
		}
		num -= num_bear;
		if (num >= 0) { /*sick animal is tiger*/
			cout << "Tiger " << num + 1 << " is sick" << endl;
			saved = save_animal(tigers[num].sick_cost());
			if (saved == 1) {
				bank -= tigers[num].sick_cost();
			}
			else {
				kill_tiger(num);
			}
		}
	}
}

/**********************************************************
 ** Function: boom
 ** Description: adds extra revenue to bank
 ** Parameters: none
 ** Pre-Conditions: num_seal is accurate
 ** Post-Conditions: money added for each seal (150-400)
 *********************************************************/

void Zoo::boom() {
	float rev = 0;
	for (int i = 0; i < num_seal; i++) {
		rev += seals[i].boom();
	}
	bank += rev;
	cout << "You made $" << rev << " extra due to an attendance boom." << endl;
	cout << "You now have $" << bank << endl;
}

/**********************************************************
 ** Function: birth
 ** Description: selects random adult and adds babies to appropriate array
 ** Parameters: none
 ** Pre-Conditions: animal counters are accurate
 ** Post-Conditions: 0, 1, 2, or 3 babies added to zoo
 *********************************************************/

void Zoo::birth() {
	int seal_adults = count_seals();
	int bear_adults = count_bears();
	int tiger_adults = count_tigers();
	if (seal_adults + bear_adults + tiger_adults > 0) { /*there are adults*/
		int num = rand() % (seal_adults + bear_adults + tiger_adults);
		if (num + 1 <= seal_adults) {
			cout << "Sea Lion " << num + 1 << " gave birth" << endl;
			for (int i = 0; i < seals[num].get_baby_rate(); i++) {
				add_seal(-1);
			}
			num = -1;
		}
		num -= seal_adults;
		if (num + 1 <= bear_adults && num >= 0) {
			cout << "Bear " << num + 1 << " gave birth" << endl;
			for (int i = 0; i < bears[num].get_baby_rate(); i++) {
				add_bear(-1);
			}
			num = -1;
		}
		num -= bear_adults;
		if (num >= 0) {
			cout << "Tiger " << num + 1 << " gave birth" << endl;
			for (int i = 0; i < tigers[num].get_baby_rate(); i++) {
				add_tiger(-1);
			}
			num = -1;
		}
	}
}

/**********************************************************
 ** Function: revenue
 ** Description: adds monthly revenue to bank
 ** Parameters: none
 ** Pre-Conditions: animal counters are accurate
 ** Post-Conditions: bank is increased
 *********************************************************/

void Zoo::revenue() {
	float rev = 0;
	for (int i = 0; i < num_seal; i++) {
		rev += seals[i].revenue();
	}
	for (int i = 0; i < num_bear; i++) {
		rev += bears[i].revenue();
	}
	for (int i = 0; i < num_tiger; i++) {
		rev += tigers[i].revenue();
	}
	bank += rev;
	cout << "You made $" << rev << " in monthly revenue." << endl;
	cout << "You now have $" << bank << endl;
}

/**********************************************************
 ** Function: purchase
 ** Description: gets user animal selections and executes them
 ** Parameters: none
 ** Pre-Conditions: zoo is setup
 ** Post-Conditions: subtracts cost and adds adult animals 
 *********************************************************/

void Zoo::purchase() {
	int purchase = 0;
	if (bank >= 800) { /*can purchase animals*/
		print_store();
		purchase = get_bool("Would you like to purchase an animal?: ");
		if (purchase == 1) {
			if (bank >= 1600) {
				purchase += get_bool("Would you like to purchase two animals?: ");
			}
			if (bank >= purchase * 10000) { /*Choose from all animals*/
				choose_animal(purchase);
			}
			else if (bank >= purchase * 5000) { /*can't buy tiger*/
				cout << "You can't afford tigers" << endl;
				bool seal = get_bool("Do you want to buy sea lions?: ");
				if (seal == 1) {
					for (int i = 0; i < purchase; i++) {
						add_seal(47);
						bank -= 800;
					}
				}
				else {
					for (int i = 0; i < purchase; i++) {
						add_bear(47);
						bank -= 5000;
					}
				}
			}
			else { /*can only afford seal*/
				cout << "You can only afford Sea Lions" << endl;
				for (int i = 0; i < purchase; i++) {
					add_seal(47);
					bank -= 800;
				}
			}
		}
	}
}

/**********************************************************
 ** Function: buy_food
 ** Description: user chooses an affordable food option
 ** Parameters: none
 ** Pre-Conditions: animal counters are accurate
 ** Post-Conditions: cost of food is subtracted or game ending condition is set
 *********************************************************/

void Zoo::buy_food() {
	float mult = rand() % 5 + 8; /*fluctuate base food price*/
	mult *= 0.1;
	base_food *= mult;
	float total = 0;
	for (int i = 0; i < num_seal; i++) {
		total += base_food * seals[i].get_food_mult();
	}
	for (int i = 0; i < num_bear; i++) {
		total += base_food * bears[i].get_food_mult();
	}
	for (int i = 0; i < num_tiger; i++) {
		total += base_food * tigers[i].get_food_mult();
	}
	cout << "1: Cheap food, $" << total / 2 << endl;
	cout << "2: Standard food, $" << total << endl;
	cout << "3: Premium food, $" << total * 2 << endl;
	int op = get_choice(total);
	switch (op) {
		case 1: /*cheap food*/
			bank -= total / 2;
			prob1 = 4;
			prob2 = 1;
			break;
		case 2: /*standard food*/
			bank -= total;
			prob1 = 2;
			prob2 = 2;
			break;
		case 3: /*premium food*/
			bank -= total * 2;
			prob1 = 1;
			prob2 = 2;
			break;
	}
}

/**********************************************************
 ** Function: save_animal
 ** Description: returns if user can and wants to save animal
 ** Parameters: cost to save animal
 ** Pre-Conditions: cost is correct
 ** Post-Conditions: 1: yes, 0: no
 *********************************************************/

bool Zoo::save_animal(float cost) {
	if (cost > bank) {
		cout << "You don't have enough money heal the animal" << endl;
		return 0;
	}
	return get_bool("Do you want to save the animal?: ");
}

/**********************************************************
 ** Function: count_seals
 ** Description: returns the number of adult seals
 ** Parameters: none
 ** Pre-Conditions: num_seal is correct
 ** Post-Conditions: returns num of adult seals
 *********************************************************/

int Zoo::count_seals() {
	int count = 0;
	for (int i = 0; i < num_seal; i++) {
		if (seals[i].get_age() >= 48) { /*seal is adult*/
			count++;
		}
	}
	return count;
}

/**********************************************************
 ** Function: count bears
 ** Description: returns number of adult bears
 ** Parameters: none
 ** Pre-Conditions: num_bear is correct
 ** Post-Conditions: returns num of adult bears
 *********************************************************/

int Zoo::count_bears() {
	int count = 0;
	for (int i = 0; i < num_bear; i++) {
		if (bears[i].get_age() >= 48) {
			count++;
		}
	}
	return count;
}

/**********************************************************
 ** Function: count_tigers
 ** Description: returns number of adult tigers
 ** Parameters: none
 ** Pre-Conditions: num_tiger is accurate
 ** Post-Conditions: num of tigers is returned
 *********************************************************/

int Zoo::count_tigers() {
	int count = 0;
	for (int i = 0; i < num_tiger; i++) {
		if (tigers[i].get_age() >= 48) {
			count++;
		}
	}
	return count;
}

/**********************************************************
 ** Function: print_store
 ** Description: outputs animals and there prices
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: animal costs outputted to screen
 *********************************************************/

void Zoo::print_store() {
	cout << endl;
	cout << "You can buy one or two animals" << endl;
	cout << "1. Tigers cost $10,000" << endl;
	cout << "2. Bears cost $5,000" << endl;
	cout << "3. Sea lions cost $800" << endl << endl;
}

/**********************************************************
 ** Function: get_bool
 ** Description: gets yes/no answer from user
 ** Parameters: prompt for the user
 ** Pre-Conditions: buffer is clear
 ** Post-Conditions: returns 1 for 1,y,Y and 0 for 0,n,N
 *********************************************************/

bool Zoo::get_bool(string prompt) {
	string str;
	cout << prompt;
	while(true) {
		getline(cin, str);
		/* True cases */
		if (str == "y" || str == "Y" || str == "1") {
			return 1;
		}
		else if (str == "n" || str == "N" || str == "0") {
			return 0;
		}
		cout << "Enter y or n: ";
	}	
}

/**********************************************************
 ** Function: choose_animal
 ** Description: purchases the species of user choice
 ** Parameters: num of animals to be purchased
 ** Pre-Conditions: buffer is empty
 ** Post-Conditions: cost is subtracted, animal(s) added to zoo
 *********************************************************/

void Zoo::choose_animal(int num) {
	bool bad = 1;
	string str;
	int cost = 0;
	cout << "Which type of animal would you like to purchase? (use numbers above): ";
	while(bad) {
		getline(cin, str);
		if (str == "1") {
			cost = 10000;
			bad = 0;
		}
		else if (str == "2") {
			cost = 5000;
			bad = 0;
		}
		else if (str == "3") {
			cost = 800;
			bad = 0;
		}
		else {
			cout << "Enter 1, 2, or 3" << endl;
		}
	}
	for (int i = 0; i < num; i++) {
		switch (cost) {
			case 800:
				add_seal(47);
				break;
			case 5000:
				add_bear(47);
				break;
			default:
				add_tiger(47);
		}
		bank -= cost;
	}
}

/**********************************************************
 ** Function: print_zoo
 ** Description: outputs animals, ages, and bank
 ** Parameters: none
 ** Pre-Conditions: animal counters are accurate
 ** Post-Conditions: pertinent information printed to screen
 *********************************************************/

void Zoo::print_zoo() {
	cout << "Your zoo:" << endl;
	for (int i = 0; i < num_seal; i++) {
		cout << "Sea Lion " << i + 1 << ", ";
		seals[i].print_animal();
	}
	for (int i = 0; i < num_bear; i++) {
		cout << "Bear " << i + 1 << ", ";
		bears[i].print_animal();
	}
	for (int i = 0; i < num_tiger; i++) {
		cout << "Tiger " << i + 1 << ", ";
		tigers[i].print_animal();
	}
	cout << "Bank: $" << bank << endl << endl;
}

/**********************************************************
 ** Function: get_choice
 ** Description: gets the food the user wants to buy
 ** Parameters: total: cost of standard food for the entire zoo
 ** Pre-Conditions: buffer is empty
 ** Post-Conditions: food choice is returned 
 *********************************************************/

int Zoo::get_choice(float total) {
	string str;
	string max = "3";
	if (bank >= total * 2) {
		cout << "Enter the number of the food you'd like to buy: ";
	}
	else if (bank >= total) {
		cout << "You can't afford premium, so enter 1 or 2: ";
		max = "2";
	}
	else if (bank >= total /2) {
		cout << "You can only afford cheap food." << endl;
		return 1;
	}
	else {
		cout << "You couldn't afford food and ran out of money." << endl;
		bank = -1; /*end condition*/
		return 4;
	}
	while(true) {
		getline(cin, str);
		if (str == "1") {
			return 1;
		}
		else if (str == "2") {
			return 2;
		}
		else if (max == "2" && str == "3") {
			cout << "Enter 1 or 2: ";
		}
		else if (str == "3") {
			return 3;
		}
		else {
			cout << "Enter 1, 2, or 3: ";
		}
	}
}